import { accessSync } from "node:fs";
import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";
import { request } from "node:http";
import { fileURLToPath } from "node:url";
import path from "node:path";

const rootDir = fileURLToPath(new URL("..", import.meta.url));
const vitePort = 5173;
const devServerUrl = `http://localhost:${vitePort}`;

const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";
const nodeEnv = { ...process.env, VITE_DEV_SERVER_URL: devServerUrl };

function spawnProcess(command, args, env) {
  return spawn(command, args, {
    cwd: rootDir,
    stdio: "inherit",
    shell: true,
    env
  });
}

async function waitForFile(filePath, timeoutMs) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      accessSync(filePath);
      return;
    } catch {
      await delay(200);
    }
  }
  throw new Error(`Timed out waiting for ${filePath}`);
}

async function waitForServer(url, timeoutMs) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const reachable = await new Promise((resolve) => {
      const req = request(url, (res) => {
        res.resume();
        resolve(res.statusCode && res.statusCode < 500);
      });
      req.on("error", () => resolve(false));
      req.end();
    });

    if (reachable) {
      return;
    }

    await delay(300);
  }
  throw new Error(`Timed out waiting for ${url}`);
}

const vite = spawnProcess(npmCmd, ["run", "dev:renderer"], process.env);
const tsc = spawnProcess(npmCmd, ["run", "dev:main"], process.env);

const mainEntry = path.join(rootDir, "dist/main/index.js");
const preloadEntry = path.join(rootDir, "dist/preload/index.js");
await waitForFile(mainEntry, 20000);
await waitForFile(preloadEntry, 20000);
await waitForServer(devServerUrl, 20000);

const electron = spawnProcess(npmCmd, ["run", "start"], nodeEnv);

const children = [vite, tsc, electron];
function shutdown() {
  for (const child of children) {
    if (!child.killed) {
      child.kill();
    }
  }
}

process.on("SIGINT", () => {
  shutdown();
  process.exit(0);
});

process.on("SIGTERM", () => {
  shutdown();
  process.exit(0);
});

for (const child of children) {
  child.on("exit", (code) => {
    if (code && code !== 0) {
      shutdown();
      process.exit(code);
    }
  });
}
