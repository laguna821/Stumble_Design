const { contextBridge, ipcRenderer } = require("electron");

const IPC_STUMBLE_NEXT = "stumble:next";
const IPC_OPENWEB_STATUS = "stumble:openweb:status";
const IPC_OPENWEB_SYNC = "stumble:openweb:sync";
const IPC_OPENWEB_IMPORT = "stumble:openweb:import";
const IPC_VIEW_SET_BOUNDS = "view:set-bounds";
const IPC_VIEW_SET_ZOOM = "view:set-zoom";
const IPC_VAULT_CHANGED = "vault:changed";
const IPC_VAULT_LIST = "vault:list";
const IPC_VAULT_OPEN = "vault:open-note";
const IPC_VAULT_READ = "vault:read";
const IPC_VAULT_SAVE = "vault:save";
const IPC_VAULT_SELECT = "vault:select";
const IPC_VAULT_UPDATE = "vault:update";

const stumbleApi = {
  requestNextUrl: async (payload) => {
    return ipcRenderer.invoke(IPC_STUMBLE_NEXT, payload);
  },
  getOpenWebStatus: async () => {
    return ipcRenderer.invoke(IPC_OPENWEB_STATUS);
  },
  syncOpenWebList: async () => {
    return ipcRenderer.invoke(IPC_OPENWEB_SYNC);
  },
  importOpenWebList: async () => {
    return ipcRenderer.invoke(IPC_OPENWEB_IMPORT);
  },
  setViewBounds: (bounds) => {
    ipcRenderer.send(IPC_VIEW_SET_BOUNDS, bounds);
  },
  setViewZoom: (zoomFactor) => {
    ipcRenderer.send(IPC_VIEW_SET_ZOOM, zoomFactor);
  }
};

const vaultApi = {
  selectVault: async () => {
    return ipcRenderer.invoke(IPC_VAULT_SELECT);
  },
  saveCurrentScrap: async (payload) => {
    return ipcRenderer.invoke(IPC_VAULT_SAVE, payload);
  },
  listScraps: async () => {
    return ipcRenderer.invoke(IPC_VAULT_LIST);
  },
  readScrap: async (id) => {
    return ipcRenderer.invoke(IPC_VAULT_READ, { id });
  },
  openNote: async (id) => {
    return ipcRenderer.invoke(IPC_VAULT_OPEN, { id });
  },
  updateScrap: async (payload) => {
    return ipcRenderer.invoke(IPC_VAULT_UPDATE, payload);
  },
  onChanged: (handler) => {
    const listener = () => handler();
    ipcRenderer.on(IPC_VAULT_CHANGED, listener);
    return () => {
      ipcRenderer.removeListener(IPC_VAULT_CHANGED, listener);
    };
  }
};

contextBridge.exposeInMainWorld("stumble", stumbleApi);
contextBridge.exposeInMainWorld("vault", vaultApi);
