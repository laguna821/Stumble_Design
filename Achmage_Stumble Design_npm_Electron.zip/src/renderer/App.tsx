import { useEffect, useMemo, useRef, useState } from "react";
import {
  MAX_CATEGORY_SELECTION,
  STUMBLE_CATEGORIES,
  STUMBLE_LANGUAGE_MODES,
  type ContentBlock,
  type StumbleCategory,
  type StumbleLanguageMode,
  type StumblePack
} from "../shared/stumbleConfig";

const STATUS_COPY = {
  idle: "Live site view",
  loading: "Loading sample site...",
  ready: "Live site view",
  error: "Unable to load a site"
};

type StatusKey = keyof typeof STATUS_COPY;

type StumbleSummary = {
  title: string;
  hostname: string;
  keywords: string[];
};

type StumbleResult = {
  url: string;
  summary: StumbleSummary;
};

type OpenWebStatus = {
  source: string;
  downloadedAt: string | null;
  totalDomains: number;
  customDomains: number;
};

type ScrapSummary = {
  id: string;
  title: string;
  sourceUrl: string;
  createdAt: string;
  screenshotDataUrl?: string | null;
};

type ScrapDetails = ScrapSummary & {
  notePath: string;
  screenshotDataUrl?: string | null;
  tags: string[];
  notes: string | null;
};

function formatVaultLabel(vaultPath: string | null): string {
  if (!vaultPath) {
    return "Not set";
  }

  const parts = vaultPath.split(/[/\\]+/).filter(Boolean);
  return parts[parts.length - 1] ?? vaultPath;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString();
  } catch {
    return iso;
  }
}

function formatDateTime(iso: string | null): string {
  if (!iso) {
    return "Never";
  }

  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

export default function App() {
  const [status, setStatus] = useState<StatusKey>("idle");
  const [currentUrl, setCurrentUrl] = useState<string | null>(null);
  const [summary, setSummary] = useState<StumbleSummary | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [vaultPath, setVaultPath] = useState<string | null>(null);
  const [scraps, setScraps] = useState<ScrapSummary[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedScrap, setSelectedScrap] = useState<ScrapDetails | null>(null);
  const [detailError, setDetailError] = useState<string | null>(null);
  const [tagsInput, setTagsInput] = useState("");
  const [notesInput, setNotesInput] = useState("");
  const [zoomFactor, setZoomFactor] = useState(1);
  const [isExpanded, setIsExpanded] = useState(false);
  const [detailNotes, setDetailNotes] = useState("");
  const [detailTags, setDetailTags] = useState<string[]>([]);
  const [detailSaving, setDetailSaving] = useState(false);
  const [sourcePack, setSourcePack] = useState<StumblePack>("global");
  const [languageMode, setLanguageMode] = useState<StumbleLanguageMode>("both");
  const [selectedCategories, setSelectedCategories] = useState<StumbleCategory[]>([]);
  const [blockedContent, setBlockedContent] = useState<ContentBlock>({
    adult: true,
    gambling: true,
    violence: true
  });
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [openWebStatus, setOpenWebStatus] = useState<OpenWebStatus | null>(null);
  const [openWebBusy, setOpenWebBusy] = useState(false);
  const [openWebError, setOpenWebError] = useState<string | null>(null);
  // Theme State
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem("stumble-theme") || "default";
  });

  const liveViewRef = useRef<HTMLDivElement | null>(null);
  const expandedViewRef = useRef<HTMLDivElement | null>(null);

  // Apply Theme Effect
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("stumble-theme", theme);
  }, [theme]);

  const refreshLibrary = async () => {
    if (!window.vault) {
      return;
    }

    try {
      const response = await window.vault.listScraps();
      setScraps(response.items ?? []);
    } catch {
      setScraps([]);
    }
  };

  const handleStumble = async () => {
    setStatus("loading");
    setErrorMessage(null);

    try {
      if (!window.stumble) {
        throw new Error("Stumble API not available");
      }

      const result = (await window.stumble.requestNextUrl({
        pack: sourcePack,
        language: languageMode,
        categories: selectedCategories,
        blocked: blockedContent
      })) as StumbleResult;
      setCurrentUrl(result.url);
      setSummary(result.summary);
      setStatus("ready");
      window.stumble.setViewZoom?.(zoomFactor);
    } catch (error) {
      setStatus("error");
      const message =
        error instanceof Error && error.message ? error.message : "Failed to load a site.";
      setErrorMessage(message);
    }
  };

  const handleSelectVault = async () => {
    setErrorMessage(null);

    if (!window.vault) {
      setErrorMessage("Vault API not available.");
      return;
    }

    const result = await window.vault.selectVault();
    if (result?.path) {
      setVaultPath(result.path);
      await refreshLibrary();
    }
  };

  const handleSave = async () => {
    setErrorMessage(null);

    if (!window.vault) {
      setErrorMessage("Vault API not available.");
      return;
    }

    if (!vaultPath) {
      setErrorMessage("Select a vault before saving.");
      return;
    }

    if (!currentUrl) {
      setErrorMessage("Load a site before saving.");
      return;
    }

    const tags = tagsInput
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean);

    try {
      await window.vault.saveCurrentScrap({ tags, notes: notesInput });
      await refreshLibrary();
    } catch {
      setErrorMessage("Failed to save the scrap.");
    }
  };

  const handleSelectScrap = async (scrap: ScrapSummary) => {
    setDetailError(null);

    if (!window.vault) {
      setDetailError("Vault API not available.");
      return;
    }

    try {
      const response = await window.vault.readScrap(scrap.id);
      if (!response?.scrap) {
        setDetailError("Scrap not found.");
        setSelectedScrap(null);
        return;
      }

      setSelectedScrap(response.scrap);
    } catch {
      setDetailError("Failed to load scrap details.");
    }
  };

  const handleOpenNote = async () => {
    if (!selectedScrap || !window.vault) {
      return;
    }

    try {
      await window.vault.openNote(selectedScrap.id);
    } catch {
      setDetailError("Failed to open the note.");
    }
  };

  const handleDetailSave = async () => {
    if (!selectedScrap || !window.vault?.updateScrap) {
      setDetailError("Update API not available.");
      return;
    }

    setDetailError(null);
    setDetailSaving(true);
    try {
      const response = await window.vault.updateScrap({
        id: selectedScrap.id,
        notes: detailNotes
      });
      if (response?.scrap) {
        setSelectedScrap(response.scrap);
      }
    } catch {
      setDetailError("Failed to update notes.");
    } finally {
      setDetailSaving(false);
    }
  };

  useEffect(() => {
    void refreshLibrary();
  }, [vaultPath]);

  useEffect(() => {
    if (!window.vault?.onChanged) {
      return;
    }

    const unsubscribe = window.vault.onChanged(() => {
      void refreshLibrary();
    });

    return () => {
      unsubscribe?.();
    };
  }, []);

  useEffect(() => {
    if (!selectedScrap) {
      setDetailNotes("");
      setDetailTags([]);
      return;
    }

    setDetailNotes(selectedScrap.notes ?? "");
    setDetailTags(selectedScrap.tags ?? []);
  }, [selectedScrap]);

  useEffect(() => {
    if (!window.stumble?.setViewBounds) {
      return;
    }

    let frameId: number | null = null;
    let resizeObserver: ResizeObserver | null = null;

    const getActiveElement = () =>
      isExpanded ? expandedViewRef.current : liveViewRef.current;

    const updateBounds = () => {
      const element = getActiveElement();
      if (!element) {
        return;
      }

      const rect = element.getBoundingClientRect();
      window.stumble.setViewBounds({
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height
      });
    };

    const schedule = () => {
      if (typeof requestAnimationFrame === "undefined") {
        updateBounds();
        return;
      }

      if (frameId !== null) {
        cancelAnimationFrame(frameId);
      }
      frameId = requestAnimationFrame(() => {
        frameId = null;
        updateBounds();
      });
    };

    const observeActiveElement = () => {
      resizeObserver?.disconnect();
      if (typeof ResizeObserver === "undefined") {
        resizeObserver = null;
        return;
      }

      const element = getActiveElement();
      if (!element) {
        resizeObserver = null;
        return;
      }

      resizeObserver = new ResizeObserver(() => {
        schedule();
      });
      resizeObserver.observe(element);
    };

    observeActiveElement();
    schedule();

    const capture = true;
    window.addEventListener("resize", schedule);
    window.addEventListener("scroll", schedule, { passive: true, capture });
    document.addEventListener("scroll", schedule, { passive: true, capture });

    return () => {
      resizeObserver?.disconnect();
      window.removeEventListener("resize", schedule);
      window.removeEventListener("scroll", schedule, capture);
      document.removeEventListener("scroll", schedule, capture);
      if (frameId !== null) {
        cancelAnimationFrame(frameId);
      }
    };
  }, [isExpanded]);

  const lockScroll = isExpanded || isFilterOpen;
  useEffect(() => {
    document.body.style.overflow = lockScroll ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [lockScroll]);

  useEffect(() => {
    if (!isFilterOpen) {
      return;
    }

    void refreshOpenWebStatus();
  }, [isFilterOpen]);

  useEffect(() => {
    if (!window.stumble?.setViewZoom) {
      return;
    }

    window.stumble.setViewZoom(zoomFactor);
  }, [zoomFactor]);

  const filteredScraps = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) {
      return scraps;
    }

    return scraps.filter((scrap) => {
      return (
        scrap.title.toLowerCase().includes(query) ||
        scrap.sourceUrl.toLowerCase().includes(query)
      );
    });
  }, [scraps, searchQuery]);

  const summaryChips = summary?.keywords?.length
    ? summary.keywords
    : ["Hero CTA", "Sticky nav", "Pricing grid"];

  const sourceLabel =
    sourcePack === "global"
      ? "Global sample pack"
      : sourcePack === "curated"
        ? "Curated list"
        : "Open web (Tranco)";
  const languageLabel =
    languageMode === "both" ? "Korean + English" : languageMode === "en" ? "English" : "Korean";
  const categorySummary =
    selectedCategories.length > 0 ? `${selectedCategories.length} categories` : "Any category";
  const filterSummary = `${sourceLabel} · ${languageLabel} · ${categorySummary}`;
  const categoryCount = `${selectedCategories.length}/${MAX_CATEGORY_SELECTION}`;
  const categoryLimitReached = selectedCategories.length >= MAX_CATEGORY_SELECTION;

  const toggleCategory = (category: StumbleCategory) => {
    setSelectedCategories((prev) => {
      if (prev.includes(category)) {
        return prev.filter((item) => item !== category);
      }
      if (prev.length >= MAX_CATEGORY_SELECTION) {
        return prev;
      }
      return [...prev, category];
    });
  };

  const toggleBlocked = (flag: keyof ContentBlock) => {
    setBlockedContent((prev) => ({ ...prev, [flag]: !prev[flag] }));
  };

  const refreshOpenWebStatus = async () => {
    if (!window.stumble?.getOpenWebStatus) {
      return;
    }

    try {
      const status = await window.stumble.getOpenWebStatus();
      setOpenWebStatus(status);
      setOpenWebError(null);
    } catch {
      setOpenWebError("Failed to load open web status.");
    }
  };

  const handleSyncOpenWeb = async () => {
    if (!window.stumble?.syncOpenWebList) {
      setOpenWebError("Open web sync is not available.");
      return;
    }

    setOpenWebBusy(true);
    setOpenWebError(null);
    try {
      const status = await window.stumble.syncOpenWebList();
      setOpenWebStatus(status);
    } catch {
      setOpenWebError("Failed to sync open web list.");
    } finally {
      setOpenWebBusy(false);
    }
  };

  const handleImportOpenWeb = async () => {
    if (!window.stumble?.importOpenWebList) {
      setOpenWebError("Custom list import is not available.");
      return;
    }

    setOpenWebBusy(true);
    setOpenWebError(null);
    try {
      const status = await window.stumble.importOpenWebList();
      if (status) {
        setOpenWebStatus(status);
      }
    } catch {
      setOpenWebError("Failed to import custom list.");
    } finally {
      setOpenWebBusy(false);
    }
  };

  const handleZoomChange = (delta: number) => {
    const nextZoom = Math.min(2, Math.max(0.5, Number((zoomFactor + delta).toFixed(2))));
    setZoomFactor(nextZoom);
  };

  const toggleExpanded = () => {
    setIsExpanded((prev) => !prev);
  };

  const detailDirty =
    !!selectedScrap && detailNotes !== (selectedScrap.notes ?? "");

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">S</div>
          <div className="brand-copy">
            <div className="brand-name">Stumble</div>
            <div className="brand-tagline">Local-first design discovery</div>
          </div>
        </div>

        {/* Theme Switcher */}
        <div className="theme-switcher">
          <button
            type="button"
            className="theme-btn"
            style={{ background: "#FAFAFA" }}
            title="Default (Swiss)"
            data-active={theme === "default"}
            onClick={() => setTheme("default")}
          />
          <button
            type="button"
            className="theme-btn"
            style={{ background: "#050505", borderColor: "#333" }}
            title="Neon (Dark)"
            data-active={theme === "neon"}
            onClick={() => setTheme("neon")}
          />
          <button
            type="button"
            className="theme-btn"
            style={{ background: "#F2E8D5" }}
            title="Retro (Paper)"
            data-active={theme === "retro"}
            onClick={() => setTheme("retro")}
          />
          <button
            type="button"
            className="theme-btn"
            style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}
            title="Professional (White/Navy)"
            data-active={theme === "professional"}
            onClick={() => setTheme("professional")}
          />
          <button
            type="button"
            className="theme-btn"
            style={{ background: "#0A192F", border: "1px solid #112240" }}
            title="Deep Navy"
            data-active={theme === "deep-navy"}
            onClick={() => setTheme("deep-navy")}
          />
        </div>

        <div className="top-actions">
          <button className="ghost" type="button" onClick={handleSelectVault}>
            Vault: {formatVaultLabel(vaultPath)}
          </button>
          <button className="ghost" type="button">
            Sync
          </button>
        </div>
      </header>

      <main className="panels">
        <section className="panel" role="region" aria-label="Discover panel">
          <div className="panel-header">
            <h2>Discover</h2>
            <button
              className="panel-meta-button"
              type="button"
              aria-haspopup="dialog"
              aria-expanded={isFilterOpen}
              aria-label="Open random filters"
              onClick={() => setIsFilterOpen(true)}
            >
              Random
            </button>
          </div>
          <button className="primary" type="button" onClick={handleStumble}>
            Stumble
          </button>
          <div className="filter-summary">Filters: {filterSummary}</div>
          <div className="view-controls">
            <button className="ghost" type="button" onClick={() => handleZoomChange(-0.1)}>
              Zoom -
            </button>
            <button className="ghost" type="button" onClick={() => setZoomFactor(1)}>
              Reset
            </button>
            <button className="ghost" type="button" onClick={() => handleZoomChange(0.1)}>
              Zoom +
            </button>
            <button className="ghost" type="button" onClick={toggleExpanded}>
              {isExpanded ? "Exit Full View" : "Full View"}
            </button>
            <div className="zoom-readout">{Math.round(zoomFactor * 100)}%</div>
          </div>
          <div className="live-view">
            <div className="live-view-surface" aria-live="polite" ref={liveViewRef}>
              <div className="live-placeholder">
                {currentUrl ?? STATUS_COPY[status]}
              </div>
            </div>
          </div>
          {errorMessage ? <div className="status error">{errorMessage}</div> : null}
          <div className="panel-block">
            <h3>At a glance</h3>
            <div className="summary">
              <div className="summary-line">
                {summary?.title ?? "Three-line summary placeholder for the current site."}
              </div>
              <div className="summary-line summary-muted">
                {summary?.hostname ? `Domain: ${summary.hostname}` : "Domain: --"}
              </div>
            </div>
          </div>
          <div className="panel-block">
            <h3>UI signals</h3>
            <div className="chips">
              {summaryChips.map((chip) => (
                <span className="chip" key={chip}>
                  {chip}
                </span>
              ))}
            </div>
          </div>
          <div className="panel-block">
            <h3>Tags</h3>
            <input
              className="tag-input"
              type="text"
              placeholder="typography, saas, minimal"
              value={tagsInput}
              onChange={(event) => setTagsInput(event.target.value)}
            />
          </div>
          <div className="panel-block">
            <h3>Notes</h3>
            <textarea
              className="notes-input"
              placeholder="Short observations before saving..."
              value={notesInput}
              onChange={(event) => setNotesInput(event.target.value)}
            />
          </div>
          <button className="secondary" type="button" onClick={handleSave}>
            Save to Vault
          </button>
        </section>

        <section className="panel" role="region" aria-label="Library panel">
          <div className="panel-header">
            <h2>Library</h2>
            <span className="panel-meta">Saved scraps</span>
          </div>
          <input
            className="search"
            type="search"
            placeholder="Search your library"
            aria-label="Search library"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
          />
          <div className="card-grid">
            {filteredScraps.length === 0 ? (
              <div className="empty-state">No scraps yet.</div>
            ) : (
              filteredScraps.map((scrap) => (
                <button
                  className="card"
                  type="button"
                  key={scrap.id}
                  data-selected={selectedScrap?.id === scrap.id}
                  onClick={() => handleSelectScrap(scrap)}
                >
                  <div className="card-thumb">
                    {scrap.screenshotDataUrl ? (
                      <img src={scrap.screenshotDataUrl} alt={`${scrap.title} preview`} />
                    ) : (
                      "Thumbnail"
                    )}
                  </div>
                  <div className="card-body">
                    <div className="card-title">{scrap.title}</div>
                    <div className="card-meta">{scrap.sourceUrl}</div>
                    <div className="card-meta">{formatDate(scrap.createdAt)}</div>
                  </div>
                </button>
              ))
            )}
          </div>
          <div className="panel-block">
            <div className="chips">
              <span className="chip">Typography</span>
              <span className="chip">E-commerce</span>
              <span className="chip">Editorial</span>
            </div>
          </div>
        </section>

        <section className="panel" role="region" aria-label="Item detail panel">
          <div className="panel-header">
            <h2>Item Detail</h2>
            <span className="panel-meta">Selected scrap</span>
          </div>
          {selectedScrap ? (
            <div className="detail-hero">
              <div className="detail-thumb">
                {selectedScrap.screenshotDataUrl ? (
                  <img src={selectedScrap.screenshotDataUrl} alt="Preview" />
                ) : (
                  <div className="detail-placeholder">Preview</div>
                )}
              </div>
              <div className="detail-meta">
                <div className="detail-title">{selectedScrap.title}</div>
                <div className="detail-url">{selectedScrap.sourceUrl}</div>
                <div className="detail-meta-line">
                  Saved: {formatDate(selectedScrap.createdAt)}
                </div>
                <div className="detail-actions">
                  <button className="ghost" type="button" onClick={handleOpenNote}>
                    Open note
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="detail-empty">Select a scrap from the library.</div>
          )}
          {detailError ? <div className="status error">{detailError}</div> : null}
          <div className="panel-block">
            <h3>Notes</h3>
            {selectedScrap ? (
              <>
                <textarea
                  className="notes-input detail-notes"
                  placeholder="Add notes about this scrap..."
                  value={detailNotes}
                  onChange={(event) => setDetailNotes(event.target.value)}
                />
                <div className="detail-note-actions">
                  <button
                    className="secondary"
                    type="button"
                    onClick={handleDetailSave}
                    disabled={!detailDirty || detailSaving}
                  >
                    {detailSaving ? "Saving..." : "Save Notes"}
                  </button>
                </div>
              </>
            ) : (
              <div className="note-box">Select a scrap to view notes.</div>
            )}
          </div>
          <div className="panel-block">
            <h3>Components</h3>
            {!selectedScrap ? (
              <div className="detail-empty">Select a scrap to view components.</div>
            ) : detailTags.length > 0 ? (
              <div className="chips">
                {detailTags.map((tag) => (
                  <span className="chip" key={tag}>
                    {tag}
                  </span>
                ))}
              </div>
            ) : (
              <div className="detail-empty">No components extracted yet.</div>
            )}
          </div>
        </section>
      </main>
      {isExpanded ? (
        <div className="view-overlay" role="dialog" aria-label="Expanded view">
          <div className="view-overlay-header">
            <div className="view-overlay-title">Discover</div>
            <div className="view-controls">
              <button className="ghost" type="button" onClick={() => handleZoomChange(-0.1)}>
                Zoom -
              </button>
              <button className="ghost" type="button" onClick={() => setZoomFactor(1)}>
                Reset
              </button>
              <button className="ghost" type="button" onClick={() => handleZoomChange(0.1)}>
                Zoom +
              </button>
              <button className="ghost" type="button" onClick={toggleExpanded}>
                Exit Full View
              </button>
              <div className="zoom-readout">{Math.round(zoomFactor * 100)}%</div>
            </div>
          </div>
          <div className="view-overlay-body">
            <div className="live-view live-view-expanded">
              <div
                className="live-view-surface live-view-surface-expanded"
                aria-live="polite"
                ref={expandedViewRef}
              >
                <div className="live-placeholder">
                  {currentUrl ?? STATUS_COPY[status]}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
      {isFilterOpen ? (
        <div
          className="filter-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Random filters"
          onClick={() => setIsFilterOpen(false)}
        >
          <div className="filter-panel" onClick={(event) => event.stopPropagation()}>
            <div className="filter-header">
              <div>
                <div className="filter-title">Random filters</div>
                <div className="filter-subtitle">
                  {sourceLabel} · {languageLabel} · {categoryCount} categories
                </div>
              </div>
              <button className="ghost" type="button" onClick={() => setIsFilterOpen(false)}>
                Close
              </button>
            </div>
            <div className="filter-grid">
              <div className="panel-block">
                <h3>Source</h3>
                <div className="chips">
                  <button
                    className="chip chip-toggle"
                    type="button"
                    data-active={sourcePack === "global"}
                    aria-pressed={sourcePack === "global"}
                    onClick={() => setSourcePack("global")}
                  >
                    Global sample pack
                  </button>
                  <button
                    className="chip chip-toggle"
                    type="button"
                    data-active={sourcePack === "curated"}
                    aria-pressed={sourcePack === "curated"}
                    onClick={() => setSourcePack("curated")}
                  >
                    Curated list
                  </button>
                  <button
                    className="chip chip-toggle"
                    type="button"
                    data-active={sourcePack === "openweb"}
                    aria-pressed={sourcePack === "openweb"}
                    onClick={() => setSourcePack("openweb")}
                  >
                    Open Web (Tranco)
                  </button>
                </div>
              </div>
              <div className="panel-block">
                <h3>Language</h3>
                <div className="chips">
                  {STUMBLE_LANGUAGE_MODES.map((mode) => (
                    <button
                      className="chip chip-toggle"
                      key={mode}
                      type="button"
                      data-active={languageMode === mode}
                      aria-pressed={languageMode === mode}
                      onClick={() => setLanguageMode(mode)}
                    >
                      {mode === "both" ? "Both" : mode === "en" ? "English" : "Korean"}
                    </button>
                  ))}
                </div>
              </div>
              <div className="panel-block">
                <h3>Safety filters</h3>
                <div className="chips">
                  <button
                    className="chip chip-toggle"
                    type="button"
                    data-active={blockedContent.adult}
                    aria-pressed={blockedContent.adult}
                    onClick={() => toggleBlocked("adult")}
                  >
                    Block adult
                  </button>
                  <button
                    className="chip chip-toggle"
                    type="button"
                    data-active={blockedContent.gambling}
                    aria-pressed={blockedContent.gambling}
                    onClick={() => toggleBlocked("gambling")}
                  >
                    Block gambling
                  </button>
                  <button
                    className="chip chip-toggle"
                    type="button"
                    data-active={blockedContent.violence}
                    aria-pressed={blockedContent.violence}
                    onClick={() => toggleBlocked("violence")}
                  >
                    Block violence
                  </button>
                </div>
                <div className="filter-note">Blocked content is removed before loading.</div>
              </div>
              <div className="panel-block">
                <h3>Categories ({categoryCount})</h3>
                <div className="chips">
                  {STUMBLE_CATEGORIES.map((category) => {
                    const isActive = selectedCategories.includes(category);
                    return (
                      <button
                        className="chip chip-toggle"
                        key={category}
                        type="button"
                        data-active={isActive}
                        aria-pressed={isActive}
                        disabled={categoryLimitReached && !isActive}
                        onClick={() => toggleCategory(category)}
                      >
                        {category}
                      </button>
                    );
                  })}
                </div>
                <div className="filter-note">
                  Pick up to {MAX_CATEGORY_SELECTION} categories.
                </div>
                {sourcePack === "openweb" ? (
                  <div className="filter-note">
                    Open Web ignores categories and uses a broad domain list.
                  </div>
                ) : null}
              </div>
              <div className="panel-block">
                <h3>Open Web cache</h3>
                <div className="filter-status">
                  <div>
                    Source: {openWebStatus?.source ?? "Tranco"}
                  </div>
                  <div>
                    Last sync: {formatDateTime(openWebStatus?.downloadedAt ?? null)}
                  </div>
                  <div>
                    Domains: {openWebStatus?.totalDomains ?? 0}
                  </div>
                  <div>
                    Custom domains: {openWebStatus?.customDomains ?? 0}
                  </div>
                </div>
                <div className="filter-actions">
                  <button
                    className="ghost"
                    type="button"
                    onClick={handleSyncOpenWeb}
                    disabled={openWebBusy}
                  >
                    {openWebBusy ? "Syncing..." : "Sync Tranco list"}
                  </button>
                  <button
                    className="ghost"
                    type="button"
                    onClick={handleImportOpenWeb}
                    disabled={openWebBusy}
                  >
                    Import custom list
                  </button>
                </div>
                {openWebError ? <div className="status error">{openWebError}</div> : null}
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
