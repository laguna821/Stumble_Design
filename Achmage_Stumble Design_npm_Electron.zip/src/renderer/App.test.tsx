import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import App from "./App";

describe("app shell", () => {
  it("renders the three primary panels", () => {
    render(<App />);

    expect(screen.getByRole("heading", { name: "Discover" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Library" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Item Detail" })).toBeInTheDocument();

    const panels = screen.getAllByRole("region");
    expect(panels).toHaveLength(3);
  });

  it("exposes the primary actions", () => {
    render(<App />);

    expect(screen.getByRole("button", { name: /stumble/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/search library/i)).toBeInTheDocument();
  });

  it("requests a filtered URL when stumble is clicked", async () => {
    const requestNextUrl = vi.fn(async () => ({
      url: "https://example.com",
      summary: { title: "Example", hostname: "example.com", keywords: ["example"] }
    }));
    window.stumble = {
      requestNextUrl,
      getOpenWebStatus: vi.fn(async () => ({
        source: "tranco",
        downloadedAt: null,
        totalDomains: 0,
        customDomains: 0
      })),
      syncOpenWebList: vi.fn(async () => ({
        source: "tranco",
        downloadedAt: null,
        totalDomains: 0,
        customDomains: 0
      })),
      importOpenWebList: vi.fn(async () => ({
        source: "tranco",
        downloadedAt: null,
        totalDomains: 0,
        customDomains: 0
      })),
      setViewBounds: vi.fn(),
      setViewZoom: vi.fn()
    };

    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: /stumble/i }));

    expect(requestNextUrl).toHaveBeenCalledTimes(1);
    expect(requestNextUrl).toHaveBeenCalledWith({
      pack: "global",
      language: "both",
      categories: [],
      blocked: { adult: true, gambling: true, violence: true }
    });
    expect(await screen.findByText("https://example.com")).toBeInTheDocument();
    expect(await screen.findByText(/domain: example.com/i)).toBeInTheDocument();
  });

  it("shows vault selection and save flow", async () => {
    const selectVault = vi.fn(async () => ({ path: "C:/Vault" }));
    const saveCurrentScrap = vi.fn(async () => ({ record: { id: "1", title: "x" } }));
    const listScraps = vi.fn(async () => ({ items: [] }));
    const readScrap = vi.fn(async () => null);
    const openNote = vi.fn(async () => ({ ok: true }));
    const updateScrap = vi.fn(async () => ({
      scrap: {
        id: "1",
        title: "Example",
        sourceUrl: "https://example.com",
        createdAt: "2024-01-01T00:00:00.000Z",
        notePath: "C:/Vault/Notes/example.md",
        screenshotDataUrl: null,
        tags: [],
        notes: ""
      }
    }));
    const onChanged = vi.fn(() => () => {});
    window.vault = {
      selectVault,
      saveCurrentScrap,
      listScraps,
      readScrap,
      openNote,
      updateScrap,
      onChanged
    };

    render(<App />);
    fireEvent.click(screen.getByRole("button", { name: /vault:/i }));

    expect(selectVault).toHaveBeenCalledTimes(1);
    await screen.findByText(/vault: vault/i);
    fireEvent.click(screen.getByRole("button", { name: /save to vault/i }));
    expect(saveCurrentScrap).toHaveBeenCalledTimes(1);
  });

  it("loads item detail when a scrap is selected", async () => {
    const listScraps = vi.fn(async () => ({
      items: [
        {
          id: "scrap-1",
          title: "Example",
          sourceUrl: "https://example.com",
          createdAt: "2024-01-01T00:00:00.000Z"
        }
      ]
    }));
    const readScrap = vi.fn(async () => ({
      scrap: {
        id: "scrap-1",
        title: "Example",
        sourceUrl: "https://example.com",
        createdAt: "2024-01-01T00:00:00.000Z",
        notePath: "C:/Vault/Notes/example.md",
        screenshotDataUrl: null,
        tags: ["Typography"],
        notes: "Some notes"
      }
    }));
    const openNote = vi.fn(async () => ({ ok: true }));
    const updateScrap = vi.fn(async () => ({
      scrap: {
        id: "scrap-1",
        title: "Example",
        sourceUrl: "https://example.com",
        createdAt: "2024-01-01T00:00:00.000Z",
        notePath: "C:/Vault/Notes/example.md",
        screenshotDataUrl: null,
        tags: ["Typography"],
        notes: "Some notes"
      }
    }));

    window.vault = {
      selectVault: vi.fn(async () => ({ path: "C:/Vault" })),
      saveCurrentScrap: vi.fn(async () => ({ record: { id: "1", title: "x" } })),
      listScraps,
      readScrap,
      openNote,
      updateScrap,
      onChanged: vi.fn(() => () => {})
    };

    render(<App />);

    const card = await screen.findByRole("button", { name: /example/i });
    fireEvent.click(card);

    expect(readScrap).toHaveBeenCalledWith("scrap-1");
    expect(await screen.findByText("https://example.com")).toBeInTheDocument();
    expect(await screen.findByDisplayValue("Some notes")).toBeInTheDocument();
    expect(await screen.findByText("Typography")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: /open note/i }));
    expect(openNote).toHaveBeenCalledWith("scrap-1");
  });
});
