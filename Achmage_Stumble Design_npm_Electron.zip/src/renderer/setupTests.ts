import "@testing-library/jest-dom";

type StumbleApi = {
  requestNextUrl: (payload?: {
    pack?: "curated" | "global" | "openweb";
    language?: "both" | "en" | "ko";
    categories?: string[];
    blocked?: {
      adult?: boolean;
      gambling?: boolean;
      violence?: boolean;
    };
  }) => Promise<{
    url: string;
    summary: { title: string; hostname: string; keywords: string[] };
  }>;
  getOpenWebStatus: () => Promise<{
    source: string;
    downloadedAt: string | null;
    totalDomains: number;
    customDomains: number;
  }>;
  syncOpenWebList: () => Promise<{
    source: string;
    downloadedAt: string | null;
    totalDomains: number;
    customDomains: number;
  }>;
  importOpenWebList: () => Promise<{
    source: string;
    downloadedAt: string | null;
    totalDomains: number;
    customDomains: number;
  } | null>;
  setViewBounds: (bounds: {
    x: number;
    y: number;
    width: number;
    height: number;
  }) => void;
  setViewZoom: (zoomFactor: number) => void;
};

type VaultApi = {
  selectVault: () => Promise<{ path: string } | null>;
  saveCurrentScrap: (payload?: { tags?: string[]; notes?: string }) => Promise<{
    record: { id: string; title: string };
  }>;
  listScraps: () => Promise<{
    items: {
      id: string;
      title: string;
      sourceUrl: string;
      createdAt: string;
      screenshotDataUrl?: string | null;
    }[];
  }>;
  readScrap: (id: string) => Promise<{
    scrap: {
      id: string;
      title: string;
      sourceUrl: string;
      createdAt: string;
      notePath: string;
      screenshotDataUrl?: string | null;
      tags: string[];
      notes: string | null;
    };
  } | null>;
  openNote: (id: string) => Promise<{ ok: true }>;
  updateScrap: (payload: { id: string; notes?: string }) => Promise<{
    scrap: {
      id: string;
      title: string;
      sourceUrl: string;
      createdAt: string;
      notePath: string;
      screenshotDataUrl?: string | null;
      tags: string[];
      notes: string | null;
    };
  }>;
  onChanged: (handler: () => void) => () => void;
};

declare global {
  interface Window {
    stumble: StumbleApi;
    vault: VaultApi;
  }
}

const stubStumble: StumbleApi = {
  requestNextUrl: async () => ({
    url: "https://example.com",
    summary: { title: "Example", hostname: "example.com", keywords: ["example"] }
  }),
  getOpenWebStatus: async () => ({
    source: "tranco",
    downloadedAt: null,
    totalDomains: 0,
    customDomains: 0
  }),
  syncOpenWebList: async () => ({
    source: "tranco",
    downloadedAt: null,
    totalDomains: 0,
    customDomains: 0
  }),
  importOpenWebList: async () => ({
    source: "tranco",
    downloadedAt: null,
    totalDomains: 0,
    customDomains: 0
  }),
  setViewBounds: () => {},
  setViewZoom: () => {}
};

const stubVault: VaultApi = {
  selectVault: async () => ({ path: "C:/Vault" }),
  saveCurrentScrap: async () => ({ record: { id: "1", title: "Example" } }),
  listScraps: async () => ({ items: [] }),
  readScrap: async (id: string) => ({
    scrap: {
      id,
      title: "Example",
      sourceUrl: "https://example.com",
      createdAt: "2024-01-01T00:00:00.000Z",
      notePath: "C:/Vault/Notes/example.md",
      screenshotDataUrl: null,
      tags: ["Example"],
      notes: "Example notes"
    }
  }),
  openNote: async () => ({ ok: true }),
  updateScrap: async (payload) => ({
    scrap: {
      id: payload.id,
      title: "Example",
      sourceUrl: "https://example.com",
      createdAt: "2024-01-01T00:00:00.000Z",
      notePath: "C:/Vault/Notes/example.md",
      screenshotDataUrl: null,
      tags: ["Example"],
      notes: payload.notes ?? ""
    }
  }),
  onChanged: () => () => {}
};

Object.defineProperty(window, "stumble", {
  value: stubStumble,
  writable: true
});

Object.defineProperty(window, "vault", {
  value: stubVault,
  writable: true
});
