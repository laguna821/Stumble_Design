export {};

declare global {
  interface Window {
    stumble: {
      requestNextUrl: (payload?: {
        pack?: "curated" | "global" | "openweb";
        language?: "both" | "en" | "ko";
        categories?: string[];
        blocked?: {
          adult?: boolean;
          gambling?: boolean;
          violence?: boolean;
        };
      }) => Promise<{
        url: string;
        summary: { title: string; hostname: string; keywords: string[] };
      }>;
      getOpenWebStatus: () => Promise<{
        source: string;
        downloadedAt: string | null;
        totalDomains: number;
        customDomains: number;
      }>;
      syncOpenWebList: () => Promise<{
        source: string;
        downloadedAt: string | null;
        totalDomains: number;
        customDomains: number;
      }>;
      importOpenWebList: () => Promise<{
        source: string;
        downloadedAt: string | null;
        totalDomains: number;
        customDomains: number;
      } | null>;
      setViewBounds: (bounds: {
        x: number;
        y: number;
        width: number;
        height: number;
      }) => void;
      setViewZoom: (zoomFactor: number) => void;
    };
    vault: {
      selectVault: () => Promise<{ path: string } | null>;
      saveCurrentScrap: (payload?: {
        tags?: string[];
        notes?: string;
      }) => Promise<{ record: { id: string; title: string } }>;
      listScraps: () => Promise<{
        items: {
          id: string;
          title: string;
          sourceUrl: string;
          createdAt: string;
          screenshotDataUrl?: string | null;
        }[];
      }>;
      readScrap: (id: string) => Promise<{
        scrap: {
          id: string;
          title: string;
          sourceUrl: string;
          createdAt: string;
          notePath: string;
          screenshotDataUrl?: string | null;
          tags: string[];
          notes: string | null;
        };
      } | null>;
      openNote: (id: string) => Promise<{ ok: true }>;
      updateScrap: (payload: {
        id: string;
        notes?: string;
      }) => Promise<{
        scrap: {
          id: string;
          title: string;
          sourceUrl: string;
          createdAt: string;
          notePath: string;
          screenshotDataUrl?: string | null;
          tags: string[];
          notes: string | null;
        };
      }>;
      onChanged: (handler: () => void) => () => void;
    };
  }
}
