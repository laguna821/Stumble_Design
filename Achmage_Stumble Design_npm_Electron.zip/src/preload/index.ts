import { contextBridge, ipcRenderer } from "electron";
import {
  IPC_OPENWEB_IMPORT,
  IPC_OPENWEB_STATUS,
  IPC_OPENWEB_SYNC,
  IPC_STUMBLE_NEXT
} from "../main/stumbleIpc.js";
import { IPC_VIEW_SET_BOUNDS } from "../main/viewBoundsIpc.js";
import { IPC_VIEW_SET_ZOOM } from "../main/viewZoomIpc.js";
import {
  IPC_VAULT_CHANGED,
  IPC_VAULT_LIST,
  IPC_VAULT_OPEN,
  IPC_VAULT_READ,
  IPC_VAULT_SAVE,
  IPC_VAULT_SELECT,
  IPC_VAULT_UPDATE
} from "../main/vaultIpc.js";

type VaultChangedHandler = () => void;

type SavePayload = {
  tags?: string[];
  notes?: string;
};

type StumblePayload = {
  pack?: "curated" | "global" | "openweb";
  language?: "both" | "en" | "ko";
  categories?: string[];
  blocked?: {
    adult?: boolean;
    gambling?: boolean;
    violence?: boolean;
  };
};

const stumbleApi = {
  requestNextUrl: async (payload?: StumblePayload) => {
    return ipcRenderer.invoke(IPC_STUMBLE_NEXT, payload);
  },
  getOpenWebStatus: async () => {
    return ipcRenderer.invoke(IPC_OPENWEB_STATUS);
  },
  syncOpenWebList: async () => {
    return ipcRenderer.invoke(IPC_OPENWEB_SYNC);
  },
  importOpenWebList: async () => {
    return ipcRenderer.invoke(IPC_OPENWEB_IMPORT);
  },
  setViewBounds: (bounds: { x: number; y: number; width: number; height: number }) => {
    ipcRenderer.send(IPC_VIEW_SET_BOUNDS, bounds);
  },
  setViewZoom: (zoomFactor: number) => {
    ipcRenderer.send(IPC_VIEW_SET_ZOOM, zoomFactor);
  }
};

const vaultApi = {
  selectVault: async () => {
    return ipcRenderer.invoke(IPC_VAULT_SELECT);
  },
  saveCurrentScrap: async (payload?: SavePayload) => {
    return ipcRenderer.invoke(IPC_VAULT_SAVE, payload);
  },
  listScraps: async () => {
    return ipcRenderer.invoke(IPC_VAULT_LIST);
  },
  readScrap: async (id: string) => {
    return ipcRenderer.invoke(IPC_VAULT_READ, { id });
  },
  openNote: async (id: string) => {
    return ipcRenderer.invoke(IPC_VAULT_OPEN, { id });
  },
  updateScrap: async (payload: { id: string; notes?: string }) => {
    return ipcRenderer.invoke(IPC_VAULT_UPDATE, payload);
  },
  onChanged: (handler: VaultChangedHandler) => {
    const listener = () => handler();
    ipcRenderer.on(IPC_VAULT_CHANGED, listener);
    return () => {
      ipcRenderer.removeListener(IPC_VAULT_CHANGED, listener);
    };
  }
};

contextBridge.exposeInMainWorld("stumble", stumbleApi);
contextBridge.exposeInMainWorld("vault", vaultApi);
