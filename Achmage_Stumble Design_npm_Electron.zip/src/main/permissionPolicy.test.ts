/* @vitest-environment node */
import type { Session, WebContents } from "electron";
import { describe, expect, it } from "vitest";
import { applyPermissionPolicy, shouldAllowPermission } from "./permissionPolicy.js";

describe("permission policy", () => {
  it("denies all permissions by default", () => {
    expect(shouldAllowPermission("media")).toBe(false);
    expect(shouldAllowPermission("geolocation")).toBe(false);
  });

  it("wires handlers that deny requests", () => {
    const handlers: {
      request?: (
        webContents: WebContents,
        permission: string,
        callback: (allowed: boolean) => void
      ) => void;
      check?: (webContents: WebContents, permission: string) => boolean;
    } = {};

    const session = {
      setPermissionRequestHandler: (
        handler: (
          webContents: WebContents,
          permission: string,
          callback: (allowed: boolean) => void
        ) => void
      ) => {
        handlers.request = handler;
      },
      setPermissionCheckHandler: (
        handler: (webContents: WebContents, permission: string) => boolean
      ) => {
        handlers.check = handler;
      }
    } as unknown as Session;

    applyPermissionPolicy(session);

    let requestAllowed: boolean | undefined;
    handlers.request?.({} as WebContents, "media", (allowed) => {
      requestAllowed = allowed;
    });

    expect(requestAllowed).toBe(false);
    expect(handlers.check?.({} as WebContents, "geolocation")).toBe(false);
  });
});
