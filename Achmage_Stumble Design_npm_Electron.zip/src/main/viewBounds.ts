export type ViewBounds = {
  x: number;
  y: number;
  width: number;
  height: number;
};

type BoundsPayload = {
  x?: unknown;
  y?: unknown;
  width?: unknown;
  height?: unknown;
};

type BoundsLimit = {
  width: number;
  height: number;
};

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

export function normalizeViewBounds(
  payload: unknown,
  limit?: BoundsLimit
): ViewBounds | null {
  if (!payload || typeof payload !== "object") {
    return null;
  }

  const record = payload as BoundsPayload;
  if (
    !isFiniteNumber(record.x) ||
    !isFiniteNumber(record.y) ||
    !isFiniteNumber(record.width) ||
    !isFiniteNumber(record.height)
  ) {
    return null;
  }

  const maxWidth = limit ? Math.max(0, Math.round(limit.width)) : Number.MAX_SAFE_INTEGER;
  const maxHeight = limit ? Math.max(0, Math.round(limit.height)) : Number.MAX_SAFE_INTEGER;

  let x = Math.max(0, Math.round(record.x));
  let y = Math.max(0, Math.round(record.y));
  x = clamp(x, 0, maxWidth);
  y = clamp(y, 0, maxHeight);

  let width = Math.max(0, Math.round(record.width));
  let height = Math.max(0, Math.round(record.height));

  if (limit) {
    width = clamp(width, 0, Math.max(0, maxWidth - x));
    height = clamp(height, 0, Math.max(0, maxHeight - y));
  }

  return { x, y, width, height };
}
