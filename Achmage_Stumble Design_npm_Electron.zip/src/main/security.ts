import type { WebPreferences } from "electron";

export function getRendererWebPreferences(preloadPath?: string): WebPreferences {
  const preferences: WebPreferences = {
    contextIsolation: true,
    nodeIntegration: false,
    sandbox: true,
    webSecurity: true
  };

  if (preloadPath) {
    preferences.preload = preloadPath;
  }

  return preferences;
}
