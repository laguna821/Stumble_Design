const ALLOWED_SCHEMES = new Set(["http:", "https:"]);
const SAFE_INTERNAL = new Set(["about:blank"]);

export function isAllowedNavigation(rawUrl: string): boolean {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return false;
  }

  const normalized = `${parsed.protocol}${parsed.pathname}`;
  if (SAFE_INTERNAL.has(normalized)) {
    return true;
  }

  return ALLOWED_SCHEMES.has(parsed.protocol);
}
