declare module "yauzl" {
  import { EventEmitter } from "node:events";
  import { Readable } from "node:stream";

  export type Entry = {
    fileName: string;
    uncompressedSize: number;
  };

  export interface ZipFile extends EventEmitter {
    readEntry(): void;
    openReadStream(
      entry: Entry,
      callback: (error: Error | null, stream?: Readable) => void
    ): void;
    close(): void;
  }

  export function open(
    path: string,
    options: { lazyEntries?: boolean },
    callback: (error: Error | null, zipfile?: ZipFile) => void
  ): void;
}
