import {
  type ContentBlock,
  STUMBLE_CONTENT_FLAGS,
  type StumbleCategory,
  type StumbleContentFlag,
  type StumbleLanguageMode,
  type StumblePack
} from "../shared/stumbleConfig.js";

export type StumbleLanguage = "en" | "ko";

export type StumbleFilters = {
  pack: StumblePack;
  language: StumbleLanguageMode;
  categories: StumbleCategory[];
  blocked: ContentBlock;
};

export type StumbleEntry = {
  url: string;
  languages: StumbleLanguage[];
  categories: StumbleCategory[];
  flags?: Partial<Record<StumbleContentFlag, boolean>>;
};

const CURATED_PACK: StumbleEntry[] = [
  {
    url: "https://www.awwwards.com/",
    languages: ["en"],
    categories: ["inspiration", "editorial"]
  },
  {
    url: "https://land-book.com/",
    languages: ["en"],
    categories: ["inspiration", "portfolio"]
  },
  {
    url: "https://www.siteinspire.com/",
    languages: ["en"],
    categories: ["inspiration", "portfolio"]
  },
  {
    url: "https://www.hoverstat.es/",
    languages: ["en"],
    categories: ["inspiration", "editorial"]
  },
  {
    url: "https://minimal.gallery/",
    languages: ["en"],
    categories: ["inspiration"]
  },
  {
    url: "https://www.bestfolios.com/",
    languages: ["en"],
    categories: ["portfolio", "inspiration"]
  }
];

const GLOBAL_SAMPLE_PACK: StumbleEntry[] = [
  ...CURATED_PACK,
  {
    url: "https://dribbble.com/",
    languages: ["en"],
    categories: ["community", "portfolio"]
  },
  {
    url: "https://www.behance.net/",
    languages: ["en"],
    categories: ["community", "portfolio"]
  },
  {
    url: "https://onepagelove.com/",
    languages: ["en"],
    categories: ["landing", "inspiration"]
  },
  {
    url: "https://www.typewolf.com/",
    languages: ["en"],
    categories: ["editorial", "inspiration"]
  },
  {
    url: "https://www.cssdesignawards.com/",
    languages: ["en"],
    categories: ["editorial", "inspiration"]
  },
  {
    url: "https://www.framer.com/",
    languages: ["en"],
    categories: ["saas", "tools", "landing"]
  },
  {
    url: "https://webflow.com/",
    languages: ["en"],
    categories: ["saas", "tools", "landing"]
  },
  {
    url: "https://www.figma.com/",
    languages: ["en"],
    categories: ["saas", "tools"]
  },
  {
    url: "https://www.notion.so/",
    languages: ["en"],
    categories: ["saas", "product"]
  },
  {
    url: "https://linear.app/",
    languages: ["en"],
    categories: ["saas", "product", "dashboard"]
  },
  {
    url: "https://vercel.com/",
    languages: ["en"],
    categories: ["saas", "product"]
  },
  {
    url: "https://stripe.com/",
    languages: ["en"],
    categories: ["saas", "product"]
  },
  {
    url: "https://www.shopify.com/",
    languages: ["en"],
    categories: ["saas", "ecommerce"]
  },
  {
    url: "https://www.apple.com/",
    languages: ["en"],
    categories: ["product", "landing"]
  },
  {
    url: "https://www.nike.com/",
    languages: ["en"],
    categories: ["ecommerce", "product"]
  },
  {
    url: "https://www.airbnb.com/",
    languages: ["en"],
    categories: ["platform", "product"]
  },
  {
    url: "https://medium.com/",
    languages: ["en"],
    categories: ["editorial", "community"]
  },
  {
    url: "https://www.theverge.com/",
    languages: ["en"],
    categories: ["editorial"]
  },
  {
    url: "https://www.nytimes.com/",
    languages: ["en"],
    categories: ["editorial"]
  },
  {
    url: "https://www.instrument.com/",
    languages: ["en"],
    categories: ["agency", "portfolio"]
  },
  {
    url: "https://www.frog.co/",
    languages: ["en"],
    categories: ["agency", "portfolio"]
  },
  {
    url: "https://www.ideo.com/",
    languages: ["en"],
    categories: ["agency", "portfolio"]
  },
  {
    url: "https://www.coursera.org/",
    languages: ["en"],
    categories: ["education", "platform"]
  },
  {
    url: "https://www.masterclass.com/",
    languages: ["en"],
    categories: ["education", "platform", "landing"]
  },
  {
    url: "https://www.kakaocorp.com/",
    languages: ["ko"],
    categories: ["platform", "product"]
  },
  {
    url: "https://www.naver.com/",
    languages: ["ko"],
    categories: ["platform", "product"]
  },
  {
    url: "https://www.samsung.com/kr/",
    languages: ["ko"],
    categories: ["product", "landing"]
  },
  {
    url: "https://www.coupang.com/",
    languages: ["ko"],
    categories: ["ecommerce", "platform"]
  },
  {
    url: "https://www.musinsa.com/",
    languages: ["ko"],
    categories: ["ecommerce", "platform"]
  },
  {
    url: "https://www.oliveyoung.co.kr/",
    languages: ["ko"],
    categories: ["ecommerce"]
  },
  {
    url: "https://toss.im/",
    languages: ["ko"],
    categories: ["product", "landing"]
  },
  {
    url: "https://www.kurly.com/",
    languages: ["ko"],
    categories: ["ecommerce"]
  },
  {
    url: "https://www.daangn.com/",
    languages: ["ko"],
    categories: ["platform", "community"]
  },
  {
    url: "https://www.baemin.com/",
    languages: ["ko"],
    categories: ["platform", "product"]
  }
];

export const DEFAULT_BLOCKED_CONTENT: ContentBlock = {
  adult: true,
  gambling: true,
  violence: true
};

export const DEFAULT_STUMBLE_FILTERS: StumbleFilters = {
  pack: "global",
  language: "both",
  categories: [],
  blocked: DEFAULT_BLOCKED_CONTENT
};

function matchesLanguage(entry: StumbleEntry, language: StumbleLanguageMode): boolean {
  if (language === "both") {
    return true;
  }

  return entry.languages.includes(language);
}

function matchesCategories(entry: StumbleEntry, categories: StumbleCategory[]): boolean {
  if (categories.length === 0) {
    return true;
  }

  return categories.some((category) => entry.categories.includes(category));
}

function matchesBlocked(entry: StumbleEntry, blocked: ContentBlock): boolean {
  const flags = entry.flags ?? {};
  for (const flag of STUMBLE_CONTENT_FLAGS) {
    if (blocked[flag] && flags[flag]) {
      return false;
    }
  }

  return true;
}

export function filterStumbleEntries(
  entries: StumbleEntry[],
  filters: StumbleFilters
): StumbleEntry[] {
  return entries.filter((entry) => {
    return (
      matchesLanguage(entry, filters.language) &&
      matchesCategories(entry, filters.categories) &&
      matchesBlocked(entry, filters.blocked)
    );
  });
}

function pickRandomEntry(entries: StumbleEntry[]): StumbleEntry {
  if (entries.length === 0) {
    throw new Error("No sites available after filtering");
  }

  const index = Math.floor(Math.random() * entries.length);
  return entries[index];
}

export function getRandomCuratedUrl(): string {
  const entry = pickRandomEntry(CURATED_PACK);
  return entry.url;
}

export function listCuratedUrls(): string[] {
  return CURATED_PACK.map((entry) => entry.url);
}

export function listStumbleUrls(filters: StumbleFilters): string[] {
  if (filters.pack === "openweb") {
    return [];
  }

  const pack = filters.pack === "curated" ? CURATED_PACK : GLOBAL_SAMPLE_PACK;
  return filterStumbleEntries(pack, filters).map((entry) => entry.url);
}

export function getRandomStumbleUrl(filters: StumbleFilters): string {
  const candidates = listStumbleUrls(filters);
  if (candidates.length === 0) {
    throw new Error("No sites available after filtering");
  }

  const index = Math.floor(Math.random() * candidates.length);
  return candidates[index];
}
