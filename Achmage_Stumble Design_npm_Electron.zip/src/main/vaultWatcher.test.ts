/* @vitest-environment node */
import { describe, expect, it, vi } from "vitest";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { startVaultWatcher } from "./vaultWatcher.js";

describe("vault watcher", () => {
  it("notifies on markdown changes", async () => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "vault-"));
    const notesDir = path.join(root, "Notes");
    await fs.mkdir(notesDir, { recursive: true });

    const onChange = vi.fn();
    const stop = startVaultWatcher(root, onChange);

    const notePath = path.join(notesDir, "note.md");
    await fs.writeFile(notePath, "hello");

    await new Promise((resolve) => setTimeout(resolve, 400));
    stop();

    expect(onChange).toHaveBeenCalled();
  });
});
