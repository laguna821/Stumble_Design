/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { normalizeViewBounds } from "./viewBounds.js";

describe("normalizeViewBounds", () => {
  it("returns null for invalid payloads", () => {
    expect(normalizeViewBounds(null)).toBeNull();
    expect(normalizeViewBounds({})).toBeNull();
    expect(normalizeViewBounds({ x: 1, y: 2, width: "nope", height: 4 })).toBeNull();
  });

  it("normalizes and clamps to window bounds", () => {
    const bounds = normalizeViewBounds(
      { x: -10, y: 5.4, width: 999, height: 200 },
      { width: 300, height: 100 }
    );

    expect(bounds).toEqual({ x: 0, y: 5, width: 300, height: 95 });
  });
});
