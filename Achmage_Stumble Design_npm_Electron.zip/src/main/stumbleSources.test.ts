/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import {
  filterStumbleEntries,
  getRandomCuratedUrl,
  type StumbleEntry,
  type StumbleFilters,
  listCuratedUrls
} from "./stumbleSources.js";

describe("stumble sources", () => {
  it("returns urls from the curated list", () => {
    const urls = listCuratedUrls();
    const selected = getRandomCuratedUrl();

    expect(urls.length).toBeGreaterThan(0);
    expect(urls).toContain(selected);
  });

  it("filters by language, categories, and blocked content", () => {
    const entries: StumbleEntry[] = [
      {
        url: "https://example.com/en-saas",
        languages: ["en"],
        categories: ["saas"],
        flags: { adult: false }
      },
      {
        url: "https://example.com/ko-portfolio",
        languages: ["ko"],
        categories: ["portfolio"],
        flags: { adult: false }
      },
      {
        url: "https://example.com/en-flagged",
        languages: ["en"],
        categories: ["portfolio"],
        flags: { gambling: true }
      }
    ];

    const baseFilters: StumbleFilters = {
      pack: "global",
      language: "en",
      categories: ["saas", "portfolio"],
      blocked: { adult: true, gambling: true, violence: true }
    };

    const filtered = filterStumbleEntries(entries, baseFilters);
    const urls = filtered.map((entry) => entry.url);

    expect(urls).toContain("https://example.com/en-saas");
    expect(urls).not.toContain("https://example.com/ko-portfolio");
    expect(urls).not.toContain("https://example.com/en-flagged");
  });
});
