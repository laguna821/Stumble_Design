import { beforeEach, describe, expect, it, vi } from "vitest";
import type { HandlerDetails, WebContents } from "electron";
import { applyExternalLinkPolicy } from "./externalLinkPolicy.js";

const openExternal = vi.hoisted(() => vi.fn());

vi.mock("electron", () => ({
  shell: {
    openExternal
  }
}));

const createWebContents = () => {
  const api: {
    handler?: (details: HandlerDetails) => { action: "deny" | "allow" };
  } = {};

  return {
    setWindowOpenHandler: (
      handler: (details: HandlerDetails) => { action: "deny" | "allow" }
    ) => {
      api.handler = handler;
    },
    __getHandler: () => api.handler
  } as unknown as WebContents & { __getHandler: () => typeof api.handler };
};

describe("external link policy", () => {
  beforeEach(() => {
    openExternal.mockClear();
  });

  it("denies popups and opens allowed URLs externally", () => {
    const contents = createWebContents();
    applyExternalLinkPolicy(contents);

    const handler = contents.__getHandler();
    const result = handler?.({ url: "https://example.com" } as HandlerDetails);

    expect(result).toEqual({ action: "deny" });
    expect(openExternal).toHaveBeenCalledWith("https://example.com");
  });

  it("denies popups and blocks disallowed URLs", () => {
    const contents = createWebContents();
    applyExternalLinkPolicy(contents);

    const handler = contents.__getHandler();
    const result = handler?.({ url: "file:///etc/passwd" } as HandlerDetails);

    expect(result).toEqual({ action: "deny" });
    expect(openExternal).not.toHaveBeenCalled();
  });
});
