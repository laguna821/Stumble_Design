import { promises as fs } from "node:fs";
import { createWriteStream } from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import type { ReadableStream as NodeReadableStream } from "node:stream/web";
import { createInterface } from "node:readline";
import * as yauzl from "yauzl";
import {
  STUMBLE_CONTENT_FLAGS,
  type ContentBlock,
  type StumbleLanguageMode
} from "../shared/stumbleConfig.js";

export type OpenWebStatus = {
  source: "tranco";
  downloadedAt: string | null;
  totalDomains: number;
  customDomains: number;
};

const OPEN_WEB_DIR = "openweb";
const OPEN_WEB_DOMAINS_FILE = "openweb_domains.txt";
const OPEN_WEB_CUSTOM_FILE = "custom_domains.txt";
const OPEN_WEB_META_FILE = "openweb_meta.json";
const OPEN_WEB_ZIP_FILE = "tranco-top1m.csv.zip";
const TRANCOLIST_URL = "https://tranco-list.eu/top-1m.csv.zip";
const MAX_OPENWEB_DOMAINS = 1_000_000;
const MAX_CUSTOM_DOMAINS = 200_000;

const BLOCK_KEYWORDS: Record<keyof ContentBlock, string[]> = {
  adult: ["porn", "xxx", "sex", "adult", "escort", "cam", "nude"],
  gambling: ["casino", "bet", "poker", "slots", "sportsbook", "roulette", "lottery"],
  violence: ["weapon", "gun", "guns", "ammo", "violent", "violence", "gore"]
};

const KOREAN_TLDS = [".kr", ".co.kr", ".or.kr", ".go.kr", ".ac.kr", ".ne.kr"];

type OpenWebCache = {
  domains: string[];
  customDomains: string[];
  merged: string[];
  mtimeMs: number;
  customMtimeMs: number;
  filtered: Map<string, string[]>;
};

let openWebRoot: string | null = null;
let openWebCache: OpenWebCache | null = null;
let openWebSync: Promise<OpenWebStatus> | null = null;

export function setOpenWebRoot(root: string): void {
  openWebRoot = root;
  openWebCache = null;
}

function requireOpenWebRoot(): string {
  if (!openWebRoot) {
    throw new Error("Open web root not set");
  }

  return openWebRoot;
}

function resolveOpenWebPath(...segments: string[]): string {
  return path.resolve(requireOpenWebRoot(), OPEN_WEB_DIR, ...segments);
}

async function ensureOpenWebDir(): Promise<void> {
  await fs.mkdir(resolveOpenWebPath(), { recursive: true });
}

async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.stat(filePath);
    return true;
  } catch {
    return false;
  }
}

export function normalizeDomain(raw: string): string | null {
  const trimmed = raw.trim().toLowerCase();
  if (!trimmed) {
    return null;
  }

  let candidate = trimmed;
  if (candidate.includes("://")) {
    try {
      candidate = new URL(candidate).hostname;
    } catch {
      return null;
    }
  } else if (candidate.includes("/")) {
    candidate = candidate.split("/")[0];
  }

  candidate = candidate.replace(/^www\./, "");
  candidate = candidate.split(":")[0].trim();

  if (!candidate || !candidate.includes(".")) {
    return null;
  }

  if (!/^[a-z0-9.-]+$/.test(candidate)) {
    return null;
  }

  return candidate;
}

export function parseDomainLine(line: string): string | null {
  const trimmed = line.trim();
  if (!trimmed) {
    return null;
  }

  const parts = trimmed.split(/[,\s]+/);
  let raw = parts[0];
  if (parts.length > 1 && /^[0-9]+$/.test(parts[0].trim())) {
    raw = parts[1];
  }

  return normalizeDomain(raw);
}

function matchesLanguage(domain: string, language: StumbleLanguageMode): boolean {
  if (language === "both") {
    return true;
  }

  const isKorean = KOREAN_TLDS.some((tld) => domain.endsWith(tld));
  return language === "ko" ? isKorean : !isKorean;
}

function isBlocked(domain: string, blocked: ContentBlock): boolean {
  for (const flag of STUMBLE_CONTENT_FLAGS) {
    if (!blocked[flag]) {
      continue;
    }
    const keywords = BLOCK_KEYWORDS[flag];
    if (keywords.some((keyword) => domain.includes(keyword))) {
      return true;
    }
  }

  return false;
}

function buildFilterKey(language: StumbleLanguageMode, blocked: ContentBlock): string {
  return `${language}:${blocked.adult ? 1 : 0}${blocked.gambling ? 1 : 0}${blocked.violence ? 1 : 0}`;
}

async function readDomainList(filePath: string, limit: number): Promise<string[]> {
  const content = await fs.readFile(filePath, "utf8");
  const lines = content.split(/\r?\n/);
  const domains: string[] = [];

  for (const line of lines) {
    const domain = parseDomainLine(line);
    if (!domain) {
      continue;
    }
    domains.push(domain);
    if (domains.length >= limit) {
      break;
    }
  }

  return domains;
}

async function writeDomainList(filePath: string, domains: string[]): Promise<void> {
  const data = domains.join("\n");
  await fs.writeFile(filePath, data ? `${data}\n` : "", "utf8");
}

async function loadCache(): Promise<OpenWebCache> {
  const domainsPath = resolveOpenWebPath(OPEN_WEB_DOMAINS_FILE);
  const customPath = resolveOpenWebPath(OPEN_WEB_CUSTOM_FILE);

  let domainsStat: { mtimeMs: number } | null = null;
  let customStat: { mtimeMs: number } | null = null;

  try {
    const stat = await fs.stat(domainsPath);
    domainsStat = { mtimeMs: stat.mtimeMs };
  } catch {
    domainsStat = null;
  }

  try {
    const stat = await fs.stat(customPath);
    customStat = { mtimeMs: stat.mtimeMs };
  } catch {
    customStat = null;
  }

  if (
    openWebCache &&
    domainsStat &&
    openWebCache.mtimeMs === domainsStat.mtimeMs &&
    openWebCache.customMtimeMs === (customStat?.mtimeMs ?? 0)
  ) {
    return openWebCache;
  }

  const domains = domainsStat ? await readDomainList(domainsPath, MAX_OPENWEB_DOMAINS) : [];
  const customDomains = customStat
    ? await readDomainList(customPath, MAX_CUSTOM_DOMAINS)
    : [];

  const merged = mergeDomains(domains, customDomains);
  openWebCache = {
    domains,
    customDomains,
    merged,
    mtimeMs: domainsStat?.mtimeMs ?? 0,
    customMtimeMs: customStat?.mtimeMs ?? 0,
    filtered: new Map()
  };

  return openWebCache;
}

function mergeDomains(primary: string[], custom: string[]): string[] {
  if (custom.length === 0) {
    return primary;
  }

  const merged = [...primary];
  const seen = new Set(primary);
  for (const domain of custom) {
    if (seen.has(domain)) {
      continue;
    }
    seen.add(domain);
    merged.push(domain);
  }

  return merged;
}

export async function listOpenWebDomains(filters: {
  language: StumbleLanguageMode;
  blocked: ContentBlock;
}): Promise<string[]> {
  await ensureOpenWebList();
  const cache = await loadCache();
  const key = buildFilterKey(filters.language, filters.blocked);
  const cached = cache.filtered.get(key);
  if (cached) {
    return cached;
  }

  const filtered = cache.merged.filter((domain) => {
    if (!matchesLanguage(domain, filters.language)) {
      return false;
    }
    if (isBlocked(domain, filters.blocked)) {
      return false;
    }
    return true;
  });

  cache.filtered.set(key, filtered);
  return filtered;
}

export async function getOpenWebStatus(): Promise<OpenWebStatus> {
  await ensureOpenWebDir();
  const metaPath = resolveOpenWebPath(OPEN_WEB_META_FILE);
  let meta: { downloadedAt?: string } = {};

  try {
    const content = await fs.readFile(metaPath, "utf8");
    meta = JSON.parse(content);
  } catch {
    meta = {};
  }

  const cache = await loadCache();
  return {
    source: "tranco",
    downloadedAt: meta.downloadedAt ?? null,
    totalDomains: cache.domains.length,
    customDomains: cache.customDomains.length
  };
}

export async function syncOpenWebList(): Promise<OpenWebStatus> {
  if (openWebSync) {
    return openWebSync;
  }

  openWebSync = (async () => {
    await ensureOpenWebDir();
    const zipPath = resolveOpenWebPath(OPEN_WEB_ZIP_FILE);
    const tempZip = `${zipPath}.tmp`;
    const domainsPath = resolveOpenWebPath(OPEN_WEB_DOMAINS_FILE);
    const tempDomains = `${domainsPath}.tmp`;

    try {
      await downloadFile(TRANCOLIST_URL, tempZip);
      const count = await extractZipDomains(tempZip, tempDomains);

      await fs.rm(zipPath, { force: true });
      await fs.rm(domainsPath, { force: true });
      await fs.rename(tempZip, zipPath);
      await fs.rename(tempDomains, domainsPath);

      const meta = {
        source: "tranco",
        downloadedAt: new Date().toISOString(),
        totalDomains: count
      };
      await fs.writeFile(
        resolveOpenWebPath(OPEN_WEB_META_FILE),
        JSON.stringify(meta, null, 2),
        "utf8"
      );
    } catch (error) {
      await fs.rm(tempZip, { force: true });
      await fs.rm(tempDomains, { force: true });
      throw error;
    }

    openWebCache = null;
    return getOpenWebStatus();
  })();

  try {
    return await openWebSync;
  } finally {
    openWebSync = null;
  }
}

export async function importCustomList(filePath: string): Promise<OpenWebStatus> {
  await ensureOpenWebDir();
  const domains = await readDomainList(filePath, MAX_CUSTOM_DOMAINS);
  const unique = Array.from(new Set(domains));
  await writeDomainList(resolveOpenWebPath(OPEN_WEB_CUSTOM_FILE), unique);
  openWebCache = null;
  return getOpenWebStatus();
}

async function downloadFile(url: string, filePath: string): Promise<void> {
  const response = await fetch(url);
  if (!response.ok || !response.body) {
    throw new Error(`Failed to download open web list (${response.status})`);
  }

  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const fileStream = createWriteStream(filePath);
  const body = response.body as NodeReadableStream<Uint8Array> | null;
  if (!body) {
    throw new Error("Failed to download open web list (no body)");
  }

  await pipeline(Readable.fromWeb(body), fileStream);
}

async function extractZipDomains(zipPath: string, outputPath: string): Promise<number> {
  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true }, (error, zipfile) => {
      if (error || !zipfile) {
        reject(error ?? new Error("Failed to open zip file"));
        return;
      }

      let resolved = false;
      zipfile.on("entry", (entry) => {
        if (!entry.fileName.endsWith(".csv")) {
          zipfile.readEntry();
          return;
        }

        zipfile.openReadStream(entry, (streamError, stream) => {
          if (streamError || !stream) {
            reject(streamError ?? new Error("Failed to read zip entry"));
            return;
          }

          const reader = createInterface({ input: stream, crlfDelay: Infinity });
          const writer = createWriteStream(outputPath);
          let count = 0;

          const processStream = async () => {
            try {
              for await (const line of reader) {
                const domain = parseDomainLine(line);
                if (!domain) {
                  continue;
                }
                writer.write(`${domain}\n`);
                count += 1;
                if (count >= MAX_OPENWEB_DOMAINS) {
                  break;
                }
              }
              stream.destroy();
              writer.end();
              await new Promise<void>((resolveFinish, rejectFinish) => {
                writer.on("finish", () => resolveFinish());
                writer.on("error", (err) => rejectFinish(err));
              });
              if (!resolved) {
                resolved = true;
                zipfile.close();
                resolve(count);
              }
            } catch (err) {
              if (!resolved) {
                resolved = true;
                zipfile.close();
                reject(err);
              }
            }
          };

          void processStream();
        });
      });

      zipfile.on("end", () => {
        if (!resolved) {
          resolved = true;
          reject(new Error("No CSV entry found in open web list"));
        }
      });

      zipfile.readEntry();
    });
  });
}

async function ensureOpenWebList(): Promise<void> {
  const listPath = resolveOpenWebPath(OPEN_WEB_DOMAINS_FILE);
  if (await fileExists(listPath)) {
    return;
  }

  await syncOpenWebList();
}
