/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  buildFrontmatter,
  buildNoteFilename,
  getScrapDetails,
  parseFrontmatter,
  setVaultRoot,
  updateScrapNotes
} from "./vaultService.js";

describe("vault service helpers", () => {
  it("builds stable note filenames", () => {
    const name = buildNoteFilename(
      "2024-01-01T00:00:00.000Z",
      "https://example.com",
      "abc123"
    );

    expect(name).toBe("2024-01-01__example-com__abc123.md");
  });

  it("formats and parses frontmatter", () => {
    const frontmatter = buildFrontmatter({
      id: "abc123",
      createdAt: "2024-01-01T00:00:00.000Z",
      sourceUrl: "https://example.com",
      title: "Example",
      screenshotAsset: "Assets/abc123/screenshot.png",
      tags: ["Typography", "Landing"]
    });

    const parsed = parseFrontmatter(`${frontmatter}\n\nBody`);

    expect(parsed?.id).toBe("abc123");
    expect(parsed?.title).toBe("Example");
    expect(parsed?.source_url).toBe("https://example.com");
    expect(parsed?.screenshot_asset).toBe("Assets/abc123/screenshot.png");
  });

  it("reads tags and notes and updates the notes section", async () => {
    const root = mkdtempSync(path.join(tmpdir(), "stumble-vault-"));
    const notesDir = path.join(root, "Notes");
    mkdirSync(notesDir, { recursive: true });
    setVaultRoot(root);

    const id = "note-1";
    const createdAt = "2024-01-01T00:00:00.000Z";
    const frontmatter = buildFrontmatter({
      id,
      createdAt,
      sourceUrl: "https://example.com",
      title: "Example",
      screenshotAsset: "Assets/note-1/screenshot.png",
      tags: ["Design", "Gallery"]
    });

    const content = `${frontmatter}\n\n## Notes\n\nHello notes\n`;
    const notePath = path.join(notesDir, buildNoteFilename(createdAt, "https://example.com", id));
    writeFileSync(notePath, content, "utf8");

    const details = await getScrapDetails(id);
    expect(details?.tags).toEqual(["Design", "Gallery"]);
    expect(details?.notes).toBe("Hello notes");

    const updated = await updateScrapNotes(id, "Updated notes");
    expect(updated?.notes).toBe("Updated notes");
    const updatedFile = readFileSync(notePath, "utf8");
    expect(updatedFile).toContain("## Notes");
    expect(updatedFile).toContain("Updated notes");
  });
});
