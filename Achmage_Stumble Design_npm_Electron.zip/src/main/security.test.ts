/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { getRendererWebPreferences } from "./security.js";

describe("renderer webPreferences baseline", () => {
  it("enforces the secure defaults", () => {
    const prefs = getRendererWebPreferences();

    expect(prefs.contextIsolation).toBe(true);
    expect(prefs.nodeIntegration).toBe(false);
    expect(prefs.sandbox).toBe(true);
    expect(prefs.webSecurity).toBe(true);
  });

  it("accepts a preload path when provided", () => {
    const preloadPath = "C:/stumble/preload.js";
    const prefs = getRendererWebPreferences(preloadPath);

    expect(prefs.preload).toBe(preloadPath);
  });
});
