/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { normalizeDomain, parseDomainLine } from "./openWebSources.js";

describe("open web sources", () => {
  it("normalizes domains from urls and raw hosts", () => {
    expect(normalizeDomain("https://www.Example.com/path")).toBe("example.com");
    expect(normalizeDomain("example.com")).toBe("example.com");
    expect(normalizeDomain("example.com:8080")).toBe("example.com");
  });

  it("rejects invalid domains", () => {
    expect(normalizeDomain("not a domain")).toBeNull();
    expect(normalizeDomain("")).toBeNull();
  });

  it("parses csv-style and plain lines", () => {
    expect(parseDomainLine("1,example.com")).toBe("example.com");
    expect(parseDomainLine("example.com,tag")).toBe("example.com");
    expect(parseDomainLine("https://foo.bar/baz")).toBe("foo.bar");
  });
});
