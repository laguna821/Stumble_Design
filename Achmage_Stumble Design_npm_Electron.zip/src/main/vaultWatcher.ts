import { watch } from "node:fs";
import path from "node:path";

export type VaultWatcherStop = () => void;

export function startVaultWatcher(
  rootPath: string,
  onChange: () => void
): VaultWatcherStop {
  const notesDir = path.join(rootPath, "Notes");
  let timer: NodeJS.Timeout | null = null;

  const watcher = watch(notesDir, { persistent: true }, (_event, filename) => {
    if (filename && !filename.toString().endsWith(".md")) {
      return;
    }

    if (timer) {
      clearTimeout(timer);
    }

    timer = setTimeout(() => {
      onChange();
    }, 200);
  });

  return () => {
    if (timer) {
      clearTimeout(timer);
    }
    watcher.close();
  };
}
