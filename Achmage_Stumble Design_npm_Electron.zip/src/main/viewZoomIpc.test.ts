/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { normalizeZoomFactor } from "./viewZoomIpc.js";

describe("normalizeZoomFactor", () => {
  it("returns null for invalid payloads", () => {
    expect(normalizeZoomFactor(null)).toBeNull();
    expect(normalizeZoomFactor("1")).toBeNull();
  });

  it("clamps zoom factor to the allowed range", () => {
    expect(normalizeZoomFactor(0.1)).toBe(0.5);
    expect(normalizeZoomFactor(1)).toBe(1);
    expect(normalizeZoomFactor(3)).toBe(2);
  });
});
