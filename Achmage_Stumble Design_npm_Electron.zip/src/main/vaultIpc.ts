import { dialog, ipcMain } from "electron";
import type { BrowserWindow, OpenDialogOptions, WebContentsView } from "electron";
import {
  ensureVaultDirectories,
  getScrapDetails,
  listScraps,
  openScrapNote,
  saveCurrentScrap,
  setVaultRoot,
  updateScrapNotes
} from "./vaultService.js";
import { startVaultWatcher } from "./vaultWatcher.js";

export const IPC_VAULT_SELECT = "vault:select";
export const IPC_VAULT_SAVE = "vault:save";
export const IPC_VAULT_LIST = "vault:list";
export const IPC_VAULT_READ = "vault:read";
export const IPC_VAULT_OPEN = "vault:open-note";
export const IPC_VAULT_UPDATE = "vault:update";
export const IPC_VAULT_CHANGED = "vault:changed";

const MAX_NOTES_LENGTH = 5000;
const MAX_TAGS = 20;
const MAX_TAG_LENGTH = 40;

let stopWatcher: (() => void) | null = null;

type SavePayload = {
  tags?: string[];
  notes?: string;
};

type UpdatePayload = {
  id: string;
  notes?: string;
};

function assertNoPayload(payload: unknown): void {
  if (payload !== undefined && payload !== null) {
    throw new Error("Invalid payload for vault IPC");
  }
}

function assertIdPayload(payload: unknown): { id: string } {
  if (!payload || typeof payload !== "object") {
    throw new Error("Invalid payload for vault IPC");
  }

  const record = payload as { id?: unknown };
  if (typeof record.id !== "string" || record.id.trim().length === 0) {
    throw new Error("Invalid payload for vault IPC");
  }

  return { id: record.id.trim() };
}

function parseSavePayload(payload: unknown): SavePayload {
  if (payload === undefined || payload === null) {
    return {};
  }

  if (typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error("Invalid payload for vault save");
  }

  const record = payload as { tags?: unknown; notes?: unknown };
  const result: SavePayload = {};

  if (record.tags !== undefined) {
    if (!Array.isArray(record.tags)) {
      throw new Error("Invalid tags payload");
    }

    const tags: string[] = [];
    for (const tag of record.tags) {
      if (typeof tag !== "string") {
        continue;
      }

      const trimmed = tag.trim();
      if (!trimmed) {
        continue;
      }

      tags.push(trimmed.slice(0, MAX_TAG_LENGTH));
      if (tags.length >= MAX_TAGS) {
        break;
      }
    }

    result.tags = tags;
  }

  if (record.notes !== undefined) {
    if (typeof record.notes !== "string") {
      throw new Error("Invalid notes payload");
    }

    result.notes = record.notes.slice(0, MAX_NOTES_LENGTH);
  }

  return result;
}

function parseUpdatePayload(payload: unknown): UpdatePayload {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error("Invalid payload for vault update");
  }

  const record = payload as { id?: unknown; notes?: unknown };
  if (typeof record.id !== "string" || record.id.trim().length === 0) {
    throw new Error("Invalid payload for vault update");
  }

  const result: UpdatePayload = { id: record.id.trim() };
  if (record.notes !== undefined) {
    if (typeof record.notes !== "string") {
      throw new Error("Invalid notes payload");
    }

    result.notes = record.notes.slice(0, MAX_NOTES_LENGTH);
  }

  return result;
}

function restartWatcher(rootPath: string, notifyChanged?: () => void): void {
  if (stopWatcher) {
    stopWatcher();
  }

  stopWatcher = startVaultWatcher(rootPath, () => {
    notifyChanged?.();
  });
}

export function registerVaultHandlers(
  getWindow: () => BrowserWindow | null,
  getView: () => WebContentsView | null,
  notifyChanged?: () => void
): void {
  ipcMain.handle(IPC_VAULT_SELECT, async (_event, payload) => {
    assertNoPayload(payload);
    const browserWindow = getWindow();
    const options: OpenDialogOptions = {
      properties: ["openDirectory", "createDirectory"]
    };
    const result = browserWindow
      ? await dialog.showOpenDialog(browserWindow, options)
      : await dialog.showOpenDialog(options);

    if (result.canceled || result.filePaths.length === 0) {
      return null;
    }

    const selected = result.filePaths[0];
    setVaultRoot(selected);
    await ensureVaultDirectories(selected);
    restartWatcher(selected, notifyChanged);
    notifyChanged?.();
    return { path: selected };
  });

  ipcMain.handle(IPC_VAULT_SAVE, async (_event, payload) => {
    const options = parseSavePayload(payload);

    const view = getView();
    if (!view) {
      throw new Error("Untrusted view unavailable");
    }

    const record = await saveCurrentScrap(view, options);
    notifyChanged?.();
    return { record };
  });

  ipcMain.handle(IPC_VAULT_LIST, async (_event, payload) => {
    assertNoPayload(payload);

    const items = await listScraps();
    return { items };
  });

  ipcMain.handle(IPC_VAULT_READ, async (_event, payload) => {
    const { id } = assertIdPayload(payload);
    const scrap = await getScrapDetails(id);
    return scrap ? { scrap } : null;
  });

  ipcMain.handle(IPC_VAULT_OPEN, async (_event, payload) => {
    const { id } = assertIdPayload(payload);
    await openScrapNote(id);
    return { ok: true };
  });

  ipcMain.handle(IPC_VAULT_UPDATE, async (_event, payload) => {
    const { id, notes } = parseUpdatePayload(payload);
    const updated = await updateScrapNotes(id, notes ?? "");
    if (!updated) {
      throw new Error("Scrap not found");
    }
    notifyChanged?.();
    return { scrap: updated };
  });
}
