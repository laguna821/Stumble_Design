/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { isAllowedNavigation } from "./navigationPolicy.js";

describe("navigation policy", () => {
  it("allows http and https", () => {
    expect(isAllowedNavigation("http://example.com")).toBe(true);
    expect(isAllowedNavigation("https://example.com/path")).toBe(true);
  });

  it("allows about:blank", () => {
    expect(isAllowedNavigation("about:blank")).toBe(true);
  });

  it("blocks non-http schemes", () => {
    expect(isAllowedNavigation("file:///etc/passwd")).toBe(false);
    expect(isAllowedNavigation("javascript:alert(1)")).toBe(false);
    expect(isAllowedNavigation("data:text/plain,hello")).toBe(false);
  });

  it("blocks invalid URLs", () => {
    expect(isAllowedNavigation("not a url")).toBe(false);
  });
});
