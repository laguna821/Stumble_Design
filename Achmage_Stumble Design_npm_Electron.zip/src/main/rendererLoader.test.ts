/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { pathToFileURL } from "node:url";
import path from "node:path";
import { buildPreloadPath, buildRendererUrl } from "./rendererLoader.js";

describe("renderer loader", () => {
  it("prefers the dev server when provided", () => {
    const url = buildRendererUrl("C:/app", "http://localhost:5173");

    expect(url).toBe("http://localhost:5173");
  });

  it("resolves a file URL when no dev server is set", () => {
    const basePath = "C:/app";
    const url = buildRendererUrl(basePath);
    const expected = pathToFileURL(
      path.resolve(basePath, "dist/renderer/index.html")
    ).toString();

    expect(url).toBe(expected);
  });

  it("builds a preload path inside dist when no CJS preload exists", () => {
    const basePath = "C:/app";
    const preloadPath = buildPreloadPath(basePath);

    expect(preloadPath).toBe(path.resolve(basePath, "dist/preload/index.js"));
  });

  it("prefers a CJS preload when present", () => {
    const basePath = mkdtempSync(path.join(tmpdir(), "stumble-preload-"));
    const preloadCjs = path.resolve(basePath, "preload.cjs");
    writeFileSync(preloadCjs, "// test preload");

    const preloadPath = buildPreloadPath(basePath);

    expect(preloadPath).toBe(preloadCjs);
  });
});
