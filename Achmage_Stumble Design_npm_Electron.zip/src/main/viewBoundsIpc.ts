import { ipcMain } from "electron";
import type { BrowserWindow, WebContentsView } from "electron";
import { normalizeViewBounds } from "./viewBounds.js";

export const IPC_VIEW_SET_BOUNDS = "view:set-bounds";

export function registerViewBoundsHandlers(
  getWindow: () => BrowserWindow | null,
  getView: () => WebContentsView | null
): void {
  ipcMain.on(IPC_VIEW_SET_BOUNDS, (_event, payload) => {
    const window = getWindow();
    const view = getView();
    if (!window || !view) {
      return;
    }

    const bounds = normalizeViewBounds(payload, window.getContentBounds());
    if (!bounds) {
      return;
    }

    view.setBounds(bounds);
  });
}
