/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import {
  IPC_VAULT_CHANGED,
  IPC_VAULT_LIST,
  IPC_VAULT_OPEN,
  IPC_VAULT_READ,
  IPC_VAULT_SAVE,
  IPC_VAULT_SELECT,
  IPC_VAULT_UPDATE
} from "./vaultIpc.js";

describe("vault IPC constants", () => {
  it("exposes the channel names", () => {
    expect(IPC_VAULT_SELECT).toBe("vault:select");
    expect(IPC_VAULT_SAVE).toBe("vault:save");
    expect(IPC_VAULT_LIST).toBe("vault:list");
    expect(IPC_VAULT_READ).toBe("vault:read");
    expect(IPC_VAULT_OPEN).toBe("vault:open-note");
    expect(IPC_VAULT_UPDATE).toBe("vault:update");
    expect(IPC_VAULT_CHANGED).toBe("vault:changed");
  });
});
