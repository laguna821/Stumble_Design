import { shell } from "electron";
import type { HandlerDetails, WebContents } from "electron";
import { isAllowedNavigation } from "./navigationPolicy.js";

export function applyExternalLinkPolicy(webContents: WebContents): void {
  webContents.setWindowOpenHandler((details: HandlerDetails) => {
    if (isAllowedNavigation(details.url)) {
      void shell.openExternal(details.url);
    }

    return { action: "deny" };
  });
}
