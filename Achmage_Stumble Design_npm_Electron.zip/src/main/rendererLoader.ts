import { app } from "electron";
import { pathToFileURL } from "node:url";
import { existsSync } from "node:fs";
import path from "node:path";

export function buildRendererUrl(basePath: string, devServerUrl?: string): string {
  if (devServerUrl) {
    return devServerUrl;
  }

  const indexPath = path.resolve(basePath, "dist/renderer/index.html");
  return pathToFileURL(indexPath).toString();
}

export function buildPreloadPath(basePath: string): string {
  const cjsPath = path.resolve(basePath, "preload.cjs");
  if (existsSync(cjsPath)) {
    return cjsPath;
  }

  return path.resolve(basePath, "dist/preload/index.js");
}

export function resolveRendererUrl(): string {
  return buildRendererUrl(app.getAppPath(), process.env.VITE_DEV_SERVER_URL);
}

export function resolvePreloadPath(): string {
  return buildPreloadPath(app.getAppPath());
}
