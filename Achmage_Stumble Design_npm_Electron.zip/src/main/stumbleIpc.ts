import { app, dialog, ipcMain } from "electron";
import type { WebContentsView } from "electron";
import path from "node:path";
import {
  MAX_CATEGORY_SELECTION,
  STUMBLE_CATEGORIES,
  STUMBLE_CONTENT_FLAGS,
  STUMBLE_LANGUAGE_MODES,
  STUMBLE_PACKS,
  type ContentBlock,
  type StumbleCategory,
  type StumbleLanguageMode,
  type StumblePack
} from "../shared/stumbleConfig.js";
import { isAllowedNavigation } from "./navigationPolicy.js";
import {
  DEFAULT_STUMBLE_FILTERS,
  listStumbleUrls,
  type StumbleFilters
} from "./stumbleSources.js";
import {
  getOpenWebStatus,
  importCustomList,
  listOpenWebDomains,
  setOpenWebRoot,
  syncOpenWebList
} from "./openWebSources.js";

export const IPC_STUMBLE_NEXT = "stumble:next";
export const IPC_OPENWEB_STATUS = "stumble:openweb:status";
export const IPC_OPENWEB_SYNC = "stumble:openweb:sync";
export const IPC_OPENWEB_IMPORT = "stumble:openweb:import";
const MAX_LOAD_ATTEMPTS = 3;

type StumbleSummary = {
  title: string;
  hostname: string;
  keywords: string[];
};

type StumblePayload = {
  pack?: unknown;
  language?: unknown;
  categories?: unknown;
  blocked?: unknown;
};

type OpenWebImportPayload = {
  path?: unknown;
};

function parseStumblePayload(payload: unknown): StumbleFilters {
  const filters: StumbleFilters = {
    pack: DEFAULT_STUMBLE_FILTERS.pack,
    language: DEFAULT_STUMBLE_FILTERS.language,
    categories: [],
    blocked: { ...DEFAULT_STUMBLE_FILTERS.blocked }
  };

  if (payload === undefined || payload === null) {
    return filters;
  }

  if (typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error("Invalid payload for stumble:next");
  }

  const record = payload as StumblePayload;

  if (record.pack !== undefined) {
    const allowedPacks = new Set<StumblePack>(STUMBLE_PACKS);
    if (!allowedPacks.has(record.pack as StumblePack)) {
      throw new Error("Invalid pack for stumble:next");
    }
    filters.pack = record.pack as StumblePack;
  }

  if (record.language !== undefined) {
    const allowedLanguages = new Set<StumbleLanguageMode>(STUMBLE_LANGUAGE_MODES);
    if (!allowedLanguages.has(record.language as StumbleLanguageMode)) {
      throw new Error("Invalid language for stumble:next");
    }
    filters.language = record.language as StumbleLanguageMode;
  }

  if (record.categories !== undefined) {
    if (!Array.isArray(record.categories)) {
      throw new Error("Invalid categories for stumble:next");
    }

    const allowed = new Set<StumbleCategory>(STUMBLE_CATEGORIES);
    const selected: StumbleCategory[] = [];
    for (const category of record.categories) {
      if (typeof category !== "string") {
        continue;
      }
      if (!allowed.has(category as StumbleCategory)) {
        continue;
      }
      if (selected.includes(category as StumbleCategory)) {
        continue;
      }

      selected.push(category as StumbleCategory);
      if (selected.length >= MAX_CATEGORY_SELECTION) {
        break;
      }
    }

    filters.categories = selected;
  }

  if (record.blocked !== undefined) {
    if (typeof record.blocked !== "object" || record.blocked === null || Array.isArray(record.blocked)) {
      throw new Error("Invalid blocked content for stumble:next");
    }

    const blocked = record.blocked as Partial<ContentBlock>;
    for (const flag of STUMBLE_CONTENT_FLAGS) {
      const value = blocked[flag];
      if (value === undefined) {
        continue;
      }
      if (typeof value !== "boolean") {
        throw new Error("Invalid blocked content for stumble:next");
      }
      filters.blocked[flag] = value;
    }
  }

  return filters;
}

function extractKeywords(title: string): string[] {
  const tokens = title
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((word) => word.length > 3);

  const unique: string[] = [];
  for (const token of tokens) {
    if (!unique.includes(token)) {
      unique.push(token);
    }
    if (unique.length >= 4) {
      break;
    }
  }

  return unique;
}

function buildSummary(url: string, title: string): StumbleSummary {
  let hostname = "";
  try {
    hostname = new URL(url).hostname;
  } catch {
    hostname = "";
  }

  return {
    title: title || hostname || url,
    hostname,
    keywords: extractKeywords(title)
  };
}

export function registerStumbleHandlers(
  getView: () => WebContentsView | null
): void {
  const userDataRoot = app.getPath("userData");
  setOpenWebRoot(path.join(userDataRoot, "stumble"));

  ipcMain.handle(IPC_STUMBLE_NEXT, async (_event, payload) => {
    const filters = parseStumblePayload(payload);

    const view = getView();
    if (!view) {
      throw new Error("Untrusted view unavailable");
    }

    const candidates =
      filters.pack === "openweb"
        ? await listOpenWebDomains({ language: filters.language, blocked: filters.blocked })
        : listStumbleUrls(filters);
    if (candidates.length === 0) {
      let hint = "No sites match the current filters.";
      if (filters.pack === "curated" && filters.language === "ko") {
        hint = "No curated sites in Korean. Switch Language to Both or English.";
      } else if (filters.pack === "openweb") {
        hint = "Open Web list is empty. Sync the list in Random filters.";
      } else if (filters.categories.length > 0) {
        hint = "No sites match the current filters. Try clearing categories or switching Language.";
      }

      throw new Error(hint);
    }

    const attempts = Math.min(MAX_LOAD_ATTEMPTS, candidates.length);
    const tried = new Set<string>();
    let lastError: unknown;

    for (let i = 0; i < attempts; i += 1) {
      let candidate = candidates[Math.floor(Math.random() * candidates.length)];
      let nextUrl =
        filters.pack === "openweb" ? `https://${candidate}` : candidate;
      let guard = 0;
      while (tried.has(candidate) && guard < candidates.length) {
        const retry = candidates[Math.floor(Math.random() * candidates.length)];
        candidate = retry;
        nextUrl = filters.pack === "openweb" ? `https://${retry}` : retry;
        guard += 1;
      }

      tried.add(filters.pack === "openweb" ? candidate : nextUrl);
      if (!isAllowedNavigation(nextUrl)) {
        lastError = new Error("URL blocked by policy");
        continue;
      }

      try {
        await view.webContents.loadURL(nextUrl);
        const title = view.webContents.getTitle() || new URL(nextUrl).hostname;
        const summary = buildSummary(nextUrl, title);
        return { url: nextUrl, summary };
      } catch (error) {
        if (filters.pack === "openweb" && nextUrl.startsWith("https://")) {
          const fallback = `http://${nextUrl.slice("https://".length)}`;
          try {
            await view.webContents.loadURL(fallback);
            const title =
              view.webContents.getTitle() || new URL(fallback).hostname;
            const summary = buildSummary(fallback, title);
            return { url: fallback, summary };
          } catch (fallbackError) {
            lastError = fallbackError;
            console.error("Failed to load open web URL", fallback, fallbackError);
          }
        } else {
          lastError = error;
          console.error("Failed to load URL", nextUrl, error);
        }
      }
    }

    const message =
      lastError instanceof Error ? lastError.message : String(lastError ?? "Unknown error");
    throw new Error(`Failed to load URL: ${message}`);
  });

  ipcMain.handle(IPC_OPENWEB_STATUS, async () => {
    return getOpenWebStatus();
  });

  ipcMain.handle(IPC_OPENWEB_SYNC, async () => {
    return syncOpenWebList();
  });

  ipcMain.handle(IPC_OPENWEB_IMPORT, async (_event, payload) => {
    let filePath: string | undefined;
    if (payload && typeof payload === "object") {
      const record = payload as OpenWebImportPayload;
      if (typeof record.path === "string" && record.path.trim().length > 0) {
        filePath = record.path.trim();
      }
    }

    if (!filePath) {
      const result = await dialog.showOpenDialog({
        properties: ["openFile"],
        filters: [{ name: "Domain list", extensions: ["txt", "csv"] }]
      });
      if (result.canceled || result.filePaths.length === 0) {
        return null;
      }
      filePath = result.filePaths[0];
    }

    return importCustomList(filePath);
  });
}
