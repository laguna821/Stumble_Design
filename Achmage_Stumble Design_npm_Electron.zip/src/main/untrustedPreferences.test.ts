/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import {
  UNTRUSTED_PARTITION,
  getUntrustedWebPreferences
} from "./untrustedPreferences.js";

describe("untrusted webPreferences baseline", () => {
  it("enforces the sandboxed defaults", () => {
    const prefs = getUntrustedWebPreferences();

    expect(prefs.contextIsolation).toBe(true);
    expect(prefs.nodeIntegration).toBe(false);
    expect(prefs.sandbox).toBe(true);
    expect(prefs.webSecurity).toBe(true);
    expect(prefs.allowRunningInsecureContent).toBe(false);
  });

  it("uses an isolated in-memory session partition", () => {
    const prefs = getUntrustedWebPreferences();

    expect(prefs.partition).toBe(UNTRUSTED_PARTITION);
  });

  it("does not set a preload script", () => {
    const prefs = getUntrustedWebPreferences();

    expect(prefs.preload).toBeUndefined();
  });
});
