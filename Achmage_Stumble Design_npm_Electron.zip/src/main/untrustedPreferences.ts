import type { WebPreferences } from "electron";

export const UNTRUSTED_PARTITION = "stumble-remote";

export function getUntrustedWebPreferences(): WebPreferences {
  return {
    contextIsolation: true,
    nodeIntegration: false,
    sandbox: true,
    webSecurity: true,
    allowRunningInsecureContent: false,
    javascript: true,
    partition: UNTRUSTED_PARTITION
  };
}
