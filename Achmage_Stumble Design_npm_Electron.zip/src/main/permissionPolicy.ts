import type { Session, WebContents } from "electron";

export function shouldAllowPermission(_permission: string): boolean {
  return false;
}

export function applyPermissionPolicy(session: Session): void {
  session.setPermissionRequestHandler(
    (_webContents: WebContents, permission, callback) => {
      callback(shouldAllowPermission(permission));
    }
  );

  session.setPermissionCheckHandler((_webContents, permission) => {
    return shouldAllowPermission(permission);
  });
}
