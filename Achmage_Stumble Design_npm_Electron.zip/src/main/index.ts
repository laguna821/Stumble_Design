import { app, BrowserWindow } from "electron";
import type { WebContentsView } from "electron";
import { resolvePreloadPath, resolveRendererUrl } from "./rendererLoader.js";
import { getRendererWebPreferences } from "./security.js";
import { registerVaultHandlers } from "./vaultIpc.js";
import { attachUntrustedView } from "./untrustedView.js";
import { registerStumbleHandlers } from "./stumbleIpc.js";
import { IPC_VAULT_CHANGED } from "./vaultIpc.js";
import { registerViewBoundsHandlers } from "./viewBoundsIpc.js";
import { registerViewZoomHandlers } from "./viewZoomIpc.js";

let untrustedView: WebContentsView | null = null;
let mainWindow: BrowserWindow | null = null;

export function createMainWindow(): BrowserWindow {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    backgroundColor: "#f5f2ea",
    webPreferences: getRendererWebPreferences(resolvePreloadPath())
  });

  untrustedView = attachUntrustedView(mainWindow);
  mainWindow.loadURL(resolveRendererUrl()).catch((error) => {
    console.error("Failed to load renderer", error);
  });
  return mainWindow;
}

app.whenReady().then(() => {
  registerStumbleHandlers(() => untrustedView);
  registerViewZoomHandlers(() => untrustedView);
  registerVaultHandlers(
    () => mainWindow,
    () => untrustedView,
    () => {
      if (mainWindow) {
        mainWindow.webContents.send(IPC_VAULT_CHANGED);
      }
    }
  );
  registerViewBoundsHandlers(() => mainWindow, () => untrustedView);
  createMainWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
