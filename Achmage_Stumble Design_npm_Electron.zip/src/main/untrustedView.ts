import { BrowserWindow, WebContentsView } from "electron";
import type { Event } from "electron";
import { isAllowedNavigation } from "./navigationPolicy.js";
import { applyExternalLinkPolicy } from "./externalLinkPolicy.js";
import { applyPermissionPolicy } from "./permissionPolicy.js";
import { getUntrustedWebPreferences } from "./untrustedPreferences.js";

const DEFAULT_BOUNDS = { x: 0, y: 0, width: 0, height: 0 };

function guardNavigation(event: Event, url: string): void {
  if (!isAllowedNavigation(url)) {
    event.preventDefault();
  }
}

export function createUntrustedWebContentsView(): WebContentsView {
  return new WebContentsView({
    webPreferences: getUntrustedWebPreferences()
  });
}

export function attachUntrustedView(mainWindow: BrowserWindow): WebContentsView {
  const view = createUntrustedWebContentsView();
  mainWindow.contentView.addChildView(view);
  const contents = view.webContents;

  applyExternalLinkPolicy(contents);
  applyPermissionPolicy(contents.session);
  contents.on("will-navigate", guardNavigation);
  contents.on("will-redirect", guardNavigation);

  // Basic placement until renderer-driven layout is wired.
  view.setBounds(DEFAULT_BOUNDS);
  return view;
}
