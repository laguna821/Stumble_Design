/* @vitest-environment node */
import { describe, expect, it } from "vitest";
import { IPC_STUMBLE_NEXT } from "./stumbleIpc.js";

describe("stumble IPC constants", () => {
  it("exposes the channel name", () => {
    expect(IPC_STUMBLE_NEXT).toBe("stumble:next");
  });
});
