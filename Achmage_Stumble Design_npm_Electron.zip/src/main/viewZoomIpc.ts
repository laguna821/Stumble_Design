import { ipcMain } from "electron";
import type { WebContentsView } from "electron";

export const IPC_VIEW_SET_ZOOM = "view:set-zoom";
const MIN_ZOOM = 0.5;
const MAX_ZOOM = 2;

export function normalizeZoomFactor(payload: unknown): number | null {
  if (typeof payload !== "number" || !Number.isFinite(payload)) {
    return null;
  }

  return Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, payload));
}

export function registerViewZoomHandlers(
  getView: () => WebContentsView | null
): void {
  ipcMain.on(IPC_VIEW_SET_ZOOM, (_event, payload) => {
    const view = getView();
    if (!view) {
      return;
    }

    const zoom = normalizeZoomFactor(payload);
    if (zoom === null) {
      return;
    }

    view.webContents.setZoomFactor(zoom);
  });
}
