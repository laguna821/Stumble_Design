import { randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import type { Dirent } from "node:fs";
import path from "node:path";
import { shell } from "electron";
import type { WebContentsView } from "electron";

const SCHEMA_VERSION = 1;
const MAX_TAGS = 20;
const MAX_TAG_LENGTH = 40;
const MAX_NOTES_LENGTH = 5000;

export type ScrapRecord = {
  id: string;
  title: string;
  sourceUrl: string;
  createdAt: string;
  notePath: string;
};

export type ScrapSummary = {
  id: string;
  title: string;
  sourceUrl: string;
  createdAt: string;
  screenshotDataUrl?: string | null;
};

export type ScrapDetails = ScrapSummary & {
  notePath: string;
  screenshotDataUrl?: string | null;
  tags: string[];
  notes: string | null;
};

type SaveOptions = {
  tags?: string[];
  notes?: string;
};

let vaultRoot: string | null = null;

export function setVaultRoot(rootPath: string): void {
  vaultRoot = rootPath;
}

export function getVaultRoot(): string | null {
  return vaultRoot;
}

function requireVaultRoot(): string {
  if (!vaultRoot) {
    throw new Error("Vault not set");
  }

  return vaultRoot;
}

function resolveVaultPath(root: string, ...segments: string[]): string {
  const resolved = path.resolve(root, ...segments);
  const relative = path.relative(root, resolved);
  if (relative.startsWith("..") || path.isAbsolute(relative)) {
    throw new Error("Invalid vault path");
  }

  return resolved;
}

function resolveRelativePath(root: string, relativePath: string): string {
  const parts = relativePath.split(/[\\/]+/).filter(Boolean);
  return resolveVaultPath(root, ...parts);
}

export async function ensureVaultDirectories(rootPath?: string): Promise<void> {
  const root = rootPath ?? requireVaultRoot();
  await fs.mkdir(resolveVaultPath(root, "Notes"), { recursive: true });
  await fs.mkdir(resolveVaultPath(root, "Assets"), { recursive: true });
}

function escapeYaml(value: string): string {
  return value.replace(/"/g, "\\\"");
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function normalizeTags(tags: string[] | undefined): string[] {
  if (!tags) {
    return [];
  }

  const normalized: string[] = [];
  const seen = new Set<string>();

  for (const rawTag of tags) {
    if (normalized.length >= MAX_TAGS) {
      break;
    }

    const trimmed = rawTag.trim();
    if (!trimmed) {
      continue;
    }

    const capped = trimmed.slice(0, MAX_TAG_LENGTH);
    const key = capped.toLowerCase();
    if (seen.has(key)) {
      continue;
    }

    seen.add(key);
    normalized.push(capped);
  }

  return normalized;
}

function sanitizeNotes(notes?: string): string | null {
  if (!notes) {
    return null;
  }

  const trimmed = notes.trim();
  if (!trimmed) {
    return null;
  }

  return trimmed.slice(0, MAX_NOTES_LENGTH);
}

export function buildNoteFilename(createdAt: string, sourceUrl: string, id: string): string {
  const date = createdAt.slice(0, 10);
  let hostname = "site";
  try {
    hostname = new URL(sourceUrl).hostname;
  } catch {
    hostname = "site";
  }

  const slug = slugify(hostname) || "site";
  return `${date}__${slug}__${id}.md`;
}

export function buildFrontmatter(params: {
  id: string;
  createdAt: string;
  sourceUrl: string;
  title: string;
  screenshotAsset?: string;
  tags?: string[];
}): string {
  const lines = [
    "---",
    `schema_version: ${SCHEMA_VERSION}`,
    `id: \"${escapeYaml(params.id)}\"`,
    `created_at: \"${escapeYaml(params.createdAt)}\"`,
    `source_url: \"${escapeYaml(params.sourceUrl)}\"`,
    `title: \"${escapeYaml(params.title)}\"`
  ];

  if (params.screenshotAsset) {
    lines.push(`screenshot_asset: \"${escapeYaml(params.screenshotAsset)}\"`);
  }

  const normalizedTags = normalizeTags(params.tags);
  if (normalizedTags.length > 0) {
    lines.push("tags:");
    for (const tag of normalizedTags) {
      lines.push(`  - \"${escapeYaml(tag)}\"`);
    }
  }

  lines.push("---");
  return lines.join("\n");
}

function extractFrontmatterBlock(content: string): string | null {
  const match = content.match(/^---\s*[\r\n]+([\s\S]*?)\r?\n---/);
  if (!match) {
    return null;
  }

  return match[1].trim();
}

function parseFrontmatterBlock(block: string): Record<string, string> {
  const lines = block.split(/\r?\n/).filter(Boolean);
  const result: Record<string, string> = {};

  for (const line of lines) {
    if (!line.includes(":")) {
      continue;
    }

    const [rawKey, ...rest] = line.split(":");
    const key = rawKey.trim();
    if (!key || key.startsWith("-")) {
      continue;
    }

    const rawValue = rest.join(":").trim();
    const value = rawValue.startsWith("\"") && rawValue.endsWith("\"")
      ? rawValue.slice(1, -1).replace(/\\\"/g, "\"")
      : rawValue;

    result[key] = value;
  }

  return result;
}

function stripQuotes(value: string): string {
  const trimmed = value.trim();
  if (
    (trimmed.startsWith("\"") && trimmed.endsWith("\"")) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1);
  }

  return trimmed;
}

function parseInlineTags(raw: string): string[] {
  const trimmed = raw.trim();
  if (!trimmed) {
    return [];
  }

  if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
    const inner = trimmed.slice(1, -1);
    return inner
      .split(",")
      .map((entry) => stripQuotes(entry))
      .map((entry) => entry.trim())
      .filter(Boolean);
  }

  return [stripQuotes(trimmed)];
}

function parseTagsFromFrontmatter(block: string): string[] {
  const lines = block.split(/\r?\n/);
  const tags: string[] = [];
  let inTags = false;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      continue;
    }

    if (!inTags) {
      if (trimmed.startsWith("tags:")) {
        const inline = trimmed.slice("tags:".length).trim();
        if (inline) {
          tags.push(...parseInlineTags(inline));
          inTags = false;
        } else {
          inTags = true;
        }
      }
      continue;
    }

    if (trimmed.startsWith("-")) {
      tags.push(stripQuotes(trimmed.slice(1)));
      continue;
    }

    if (!line.startsWith(" ") && !line.startsWith("\t")) {
      inTags = false;
    }
  }

  return normalizeTags(tags);
}

function extractNotesSection(content: string): string | null {
  const match = content.match(
    /(^|\r?\n)##\s+Notes\s*\r?\n([\s\S]*?)(\r?\n##\s+|$)/i
  );
  if (!match) {
    return null;
  }

  const raw = match[2].trimEnd();
  const trimmed = raw.trim();
  return trimmed.length > 0 ? trimmed : "";
}

function replaceNotesSection(content: string, notes: string): string {
  const sanitized = notes.trim();
  const headerMatch = content.match(/(^|\r?\n)##\s+Notes\s*\r?\n/i);
  if (!headerMatch) {
    const suffix = sanitized ? `${sanitized}\n` : "";
    return `${content.trimEnd()}\n\n## Notes\n\n${suffix}`;
  }

  const start = (headerMatch.index ?? 0) + headerMatch[0].length;
  const rest = content.slice(start);
  const nextHeader = rest.match(/\r?\n##\s+/);
  const nextHeaderIndex =
    typeof nextHeader?.index === "number" ? nextHeader.index : null;
  const end = nextHeaderIndex !== null ? start + nextHeaderIndex : content.length;
  const before = content.slice(0, start);
  const after = content.slice(end);
  const body = sanitized ? `${sanitized}\n` : "";

  return `${before}\n${body}${after}`;
}

export function parseFrontmatter(content: string): Record<string, string> | null {
  const block = extractFrontmatterBlock(content);
  if (!block) {
    return null;
  }

  return parseFrontmatterBlock(block);
}

async function readScreenshotDataUrl(
  root: string,
  relativePath: string
): Promise<string | null> {
  const resolved = resolveRelativePath(root, relativePath);
  try {
    const data = await fs.readFile(resolved);
    return `data:image/png;base64,${data.toString("base64")}`;
  } catch {
    return null;
  }
}

export async function saveCurrentScrap(
  view: WebContentsView,
  options: SaveOptions = {}
): Promise<ScrapRecord> {
  const root = requireVaultRoot();
  await ensureVaultDirectories(root);

  const sourceUrl = view.webContents.getURL();
  if (!sourceUrl || sourceUrl === "about:blank") {
    throw new Error("No page loaded");
  }

  const title = view.webContents.getTitle() || new URL(sourceUrl).hostname;
  const id = randomUUID();
  const createdAt = new Date().toISOString();

  const assetDir = resolveVaultPath(root, "Assets", id);
  await fs.mkdir(assetDir, { recursive: true });

  const screenshotPath = path.join(assetDir, "screenshot.png");
  const image = await view.webContents.capturePage();
  await fs.writeFile(screenshotPath, image.toPNG());

  const screenshotRel = path
    .join("Assets", id, "screenshot.png")
    .replace(/\\/g, "/");

  const frontmatter = buildFrontmatter({
    id,
    createdAt,
    sourceUrl,
    title,
    screenshotAsset: screenshotRel,
    tags: options.tags
  });

  const noteFilename = buildNoteFilename(createdAt, sourceUrl, id);
  const notePath = resolveVaultPath(root, "Notes", noteFilename);
  const notes = sanitizeNotes(options.notes);
  const noteBody = notes ? `\n${notes}\n` : "\n";

  const body = `${frontmatter}\n\n![](${screenshotRel})\n\n## Notes\n${noteBody}`;

  await fs.writeFile(notePath, body, "utf8");
  await shell.openPath(notePath);

  return {
    id,
    title,
    sourceUrl,
    createdAt,
    notePath
  };
}

export async function listScraps(): Promise<ScrapSummary[]> {
  const root = getVaultRoot();
  if (!root) {
    return [];
  }

  const notesDir = resolveVaultPath(root, "Notes");
  let entries: Dirent[] = [];
  try {
    entries = await fs.readdir(notesDir, { withFileTypes: true });
  } catch {
    return [];
  }

  const scraps: ScrapSummary[] = [];
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith(".md")) {
      continue;
    }

    const notePath = path.join(notesDir, entry.name);
    const content = await fs.readFile(notePath, "utf8");
    const frontmatter = parseFrontmatter(content);
    if (!frontmatter) {
      continue;
    }

    const id = frontmatter.id;
    const title = frontmatter.title;
    const sourceUrl = frontmatter.source_url;
    const createdAt = frontmatter.created_at;

    if (!id || !title || !sourceUrl || !createdAt) {
      continue;
    }

    let screenshotDataUrl: string | null = null;
    if (frontmatter.screenshot_asset) {
      screenshotDataUrl = await readScreenshotDataUrl(
        root,
        frontmatter.screenshot_asset
      );
    }

    scraps.push({ id, title, sourceUrl, createdAt, screenshotDataUrl });
  }

  return scraps.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getScrapDetails(id: string): Promise<ScrapDetails | null> {
  const root = getVaultRoot();
  if (!root) {
    return null;
  }

  const notesDir = resolveVaultPath(root, "Notes");
  let entries: Dirent[] = [];
  try {
    entries = await fs.readdir(notesDir, { withFileTypes: true });
  } catch {
    return null;
  }

  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith(".md")) {
      continue;
    }

    const notePath = path.join(notesDir, entry.name);
    const content = await fs.readFile(notePath, "utf8");
    const frontmatterBlock = extractFrontmatterBlock(content);
    if (!frontmatterBlock) {
      continue;
    }

    const frontmatter = parseFrontmatterBlock(frontmatterBlock);
    if (!frontmatter) {
      continue;
    }

    if (frontmatter.id !== id) {
      continue;
    }

    const title = frontmatter.title;
    const sourceUrl = frontmatter.source_url;
    const createdAt = frontmatter.created_at;
    if (!title || !sourceUrl || !createdAt) {
      return null;
    }

    let screenshotDataUrl: string | null = null;
    if (frontmatter.screenshot_asset) {
      screenshotDataUrl = await readScreenshotDataUrl(
        root,
        frontmatter.screenshot_asset
      );
    }

    const tags = parseTagsFromFrontmatter(frontmatterBlock);
    const notes = extractNotesSection(content);

    return {
      id,
      title,
      sourceUrl,
      createdAt,
      notePath,
      screenshotDataUrl,
      tags,
      notes
    };
  }

  return null;
}

export async function updateScrapNotes(
  id: string,
  notes: string
): Promise<ScrapDetails | null> {
  const root = getVaultRoot();
  if (!root) {
    return null;
  }

  const notesDir = resolveVaultPath(root, "Notes");
  let entries: Dirent[] = [];
  try {
    entries = await fs.readdir(notesDir, { withFileTypes: true });
  } catch {
    return null;
  }

  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith(".md")) {
      continue;
    }

    const notePath = path.join(notesDir, entry.name);
    const content = await fs.readFile(notePath, "utf8");
    const frontmatter = parseFrontmatter(content);
    if (!frontmatter) {
      continue;
    }

    if (frontmatter.id !== id) {
      continue;
    }

    const sanitized = sanitizeNotes(notes) ?? "";
    const updated = replaceNotesSection(content, sanitized);
    if (updated !== content) {
      await fs.writeFile(notePath, updated, "utf8");
    }

    return getScrapDetails(id);
  }

  return null;
}

export async function openScrapNote(id: string): Promise<void> {
  const scrap = await getScrapDetails(id);
  if (!scrap) {
    throw new Error("Scrap not found");
  }

  await shell.openPath(scrap.notePath);
}
