export const MAX_CATEGORY_SELECTION = 5;

export const STUMBLE_CATEGORIES = [
  "inspiration",
  "portfolio",
  "saas",
  "ecommerce",
  "editorial",
  "agency",
  "product",
  "landing",
  "dashboard",
  "community",
  "education",
  "platform",
  "tools"
] as const;

export type StumbleCategory = (typeof STUMBLE_CATEGORIES)[number];

export const STUMBLE_PACKS = ["global", "curated", "openweb"] as const;
export type StumblePack = (typeof STUMBLE_PACKS)[number];

export const STUMBLE_LANGUAGE_MODES = ["both", "en", "ko"] as const;
export type StumbleLanguageMode = (typeof STUMBLE_LANGUAGE_MODES)[number];

export const STUMBLE_CONTENT_FLAGS = ["adult", "gambling", "violence"] as const;
export type StumbleContentFlag = (typeof STUMBLE_CONTENT_FLAGS)[number];

export type ContentBlock = {
  adult: boolean;
  gambling: boolean;
  violence: boolean;
};
